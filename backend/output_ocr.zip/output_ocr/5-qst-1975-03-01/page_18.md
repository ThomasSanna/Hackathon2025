---
source_file: 5-qst-1975-03-01.pdf
page_number: 18
total_pages: 32
total_images: 0
---

## Contrôle des changes

(restrictions aux transferts de fonds privés d'Algérie en France).
17484. - 1" mars 1975. - M. Krieg attire l'attention de M. le ministre de l'économie et des finances sur les difficultés qu'éprouvent les citoyens français à transférer d'Algérie en France l'argent qu'ils peuvent avoir en leur possession ou qui leur est dû, alors que les transferts de fonds s'effectuent de façon illimitée en sens inverse. A titre d'exemple, il lui signale le cas d'un Français qui a prété à un citoyen algérien résidant en France et y travaillant une petite somme d'argent afin de le dépanner momentanément. Il avait été entendu que ce prèt serait remboursé par les parents de l'emprunteur qui, eux, habitent Alger. Or ceux-ci ne peuvent effectuer le petit transfert qui leur est demandé par leur fils qui, de son côté, ne dispose pas d'assez d'argent pour rembourser en France ce qu'il y a emprunté. Au moment où les relations se normalisent entre la France et l'Algérie et où l'on parle d'un prochain voyage de M. le Président de la République française en Algérie, ce genre de petits litiges créent une atmosphère uéplaisante et qu'il y aurait le plus grand intérêt à voir disparaître.

## EDUCATION

Inspecteurs départementaux (généralisation
de l'indice fonctionnel prévu par le projet * Blanchard *)
17200. - 1" mars 1975. - M. Brun appelle l'attention de M. le ministre de l'éducation sur le mécontentement provoqué parmi les inspecturs départementaux de l'éducation par le retard mis à l'application du projet * Blanchard *, qui prévoyait la création d'un huitième échelon (substitué à l'échelon \& fonctionnel *, indice nouveau majoré 698). Il lui demande s'il entre dans ses vues de faire aboutir le projet * Blanchard *, et plus particulièrement si la généralisation de l'indice fonctionnel est envisagée. Dans l'affirmative, à quule date? Sinon quelles mesures il compte prendre pour améliorer la situation de cette catégorie de fonctionnaires.

Diplômes (reconnaissance de l'équivalence de diplome d'enseignement délivré au Canada).
17217. - 1" mars 1975. - M. Barberot expose à M. le ministre de l'éducation le cas d'une personne de nationalité canadienne titulaire d'un brevet d'enseignement délivré au Canada, qui ne peut exercer en France dans un établissement d'enceignement qu'après avoir obtenu le baccalauréat. Il lui demande s'il n'estime pas qu'il serait opportun de prévoir une équivalence entre un diplome d'enseignement délivré au Canada et un diplome français afin que ne soit pas exigé pour les titulaires du diplome canadien la possession du baccalauréat.

Bourses et allocations d'éludes
(élergissement du nombre de bénéficiaires).
17223. - 1" mars 1975. - M. Briane attire l'attention de M. le ministre de l'éducation sur l'insuffisance actuelle du montant des bourses scolaires allouées aux familles et sur l'inadéquation du barénue utilisé pour le calcul de ces bourses, lequel a, en fait, pour conséquence, d'exclure du bénéfice des bourses de très nombreuses familles ayant des revenus modestes qui ne peuvent supporter les frais de scolarité de leurs enfants en faisant appel à leurs souls ressources. Il lui demande quelles mesure le gouvernement envisage de prendre afin que les bourses scolaires puissent effectivement remplir leur rôle en donnant à tous les enfants les mêmes chances quel que soit le revenu de leurs parents.

Etablissements scolaires (aménagement du statut des agents auxiliaires chargés de fonctions de conseiller d'éducation).
17225. - 1" mars 1975. - M. Barberot attire l'attention de M. le ministre de l'éducation sur la situation défavorisée dans. laquelle sont maintenus les agents auxiliaires chargés de fonctions de conseiller et conseiller principal d'éducation. A la suite de la réunion d'un groupe de travail et des consultations auxquelles ce groupe a procédé, un certain nombre de mesures ont été envisagées. Les intéressés souhaitent que des décisions soient prises notamment en ce qui concerne les points suivants: passage transitoire à compter du $1^{\text {er Janvier }} 1975$ dans la catégorie des MA II et III; heures supplémentaires pour tous y compris pour ceux qui n'occupent pas un poste vacant; organisation avant juin 1975 d'un concours spécial en vue de titulariser comme conseiller d'éducation ou conseiller principal d'éducation, selon les diplômes et l'ancienneté, l'ensemble des auxiliaires, ce concours pouvant être renouvelé pendant plusieurs années; titularisation directe selon les services, les
titres, les charges familiales, des plus anciens chargés de fonction; stage de formation p: les nouveaux auxiliaires, dès septembre 1975. Il lui demande de - vouloir préciser ses intentions en ce qui concerne ces différentes requêtes.

## Constructions scolaires

(réalisation et financement d'un C. E.S. à Saint-Loubès (Gironde)).
17236. - 1" mars 1975. - M. Hadrelle rappelle à M. le ministre de l'éducation sa question écrite $\mathrm{n}^{\circ} 14^{\circ} 09$ du 9 novembre 1974 pour laquelle il lui a répondu en date du 8 février 1975 d'une manière très incomplète. En effet il n'a pas fait la moindre allusion au problème grave posé par la construction d'un C. E. S. à SaintLoubès (Gironde) dont le financement nous avait été assuré pour 1975 (lettre du préfet de région en date du 27 mars 1974). Il lui demande donc de lui indiquer ce qu'il compte entreprendre pour faire en sorte que le C. E. S. de Saint-Loubès ouvre ses portes le plus rapidement possible, ce qui s'avère non seulement indispensable mais nécessaire pour l'ensemble du secteur scolaire concerné.

## Constructions scolaires

(revalorisation des subventions de l'Etat aux communes).
17238. - 1" mars 1975. - Mme Fritsch expose à M. le ministre de l'éducation que les subventions, allouées par l'Etat aux communes pour les constructions scolaires, n'ont pas été revalorisées depuis de nombreuses années alors que is coût de la construction a subi des hausses considérrities. La subvention fixée à 74800 francs par classe, en 1962, n'a plus été revalorisée depuis cette date. D'autre part, des normes de sécurité, d'isolation et l'adjonction de salles polyvalentes ont été imposées ces derniers temps, rencinéaissant encore sensiblement le prix de ces constructions. Elle lui demande s'il n'a pas l'intention de prendre toutes décisions utiles en vu d'une adaptation du montant de ces subventions à l'augmentation du coût de la vie.

Orientation scolaire et professionnelle (reprise des travaux du groupe de travail ministériel sur la formation des conseillers d'orientation).
17256. - 1" mars 1975. - M. Dupuy demande à M. le ministre de l'éducation de lui indiquer pour quels motifs le groupe de travail ministériel sur la formation des conseillers d'orientation, envisagé pour le premier trimestre de l'année scolaire, n'a pas encore repris ses travaux. L'ouverture des ces discussions avait été annoncée au S.N.E.S. le 8 octobre, puis confirmée par M. le ministre de l'éducation à cette organisation le 25 décembre. Un vif mécontentement est créé par les carences de la formation des élèves-conseillers d'orientation qui n'est pas fonctionnée par un titre universitaire et par les aspects inadmissibles du concours de recrutement et de l'année de stage des conseillers d'orientation. Il lui demande de lui préciser la date, sans doute prochaine, à laquelle ces discussions commenceront.

Cumredmoration (information des jeunes Français sur la Résistance à l'occasion du trentième anniversaire de la libération).
17264. - 21 mars 1975. - M. Pierre Weber, évoquant le souvenir des épisodes douloureux et glorieux de la Résistance qui par son action a contribué à la capitulation des forces adversus, capitulation dont 1975 marque le trentième anniversaire, demande à M. le ministre de l'éducation s'il n'estime pas opportun de faire consacrer, à tous les niveaux de l'enseignement, plusieurs heures de cours pour mieux faire connaître aux jeunes Français et aux jeunes Françaises le mérite des résistants et leur concloure le respect et la pratique des vertus civiques et morales qui les ont unis dans leur amour de la patrie, de la liberté et dans le respect de la personne humaine. Il lui den ande également si, à l'occasion de ce trentième anniversaire, il n'envisagerait pas de faire éditer et distribuer à tous les enfants en scolarité au document objectif, clair et précis, relatant ce qu'a été la Résistance et pourquoi son esprit mérite toujours reconnaissance, respect et application.

Presse et publications (expression des points de vue de l'opposition et des syndicats représentatifs dans *Le Courrier de l'éducation *).
17278. - 1" mars 1975. - M. Mexandseu demande à M. le ministre de l'éducation de bien vouloir lui indiquer s'il entre bien dans les missions de l'Ofratern s'assurer le secrétariat de rédaction d'un bulletin de propagande politique d'inspiration gouvernementale: *Le Courrier de l'éducation *. Constatant que sont pris à partie, par avance, ceux qui exprimeraient des désaccords avec le projet