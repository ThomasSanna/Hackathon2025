# Carte Mentale - Débats parlementaires de l'Assemblée Nationale française (1er mars 1975) : Questions écrites et réponses des ministres sur des enjeux socio-économiques et législatifs

```mermaid
mindmap
  root((Débats parlementaires de l'Assemblée Nationale française - 1er mars 1975 : Enjeux socio-économiques et législatifs))
    Politique agricole et revenus des agriculteurs
      Dégradation du revenu agricole
        Baisse de 15 % du pouvoir d'achat en 1974
        Impact de l'inflation sur les prix agricoles
      Mesures demandées par les parlementaires
        Débat parlementaire sur les mesures de sauvegarde
        Trois objectifs essentiels
          Garantir une progression du pouvoir d'achat
          Organisation des marchés agricoles
          Développement des exportations
    Réglementation des médias et droits des citoyens
      Droit de réponse dans les médias
        Demande de décret d'application pour la radio et télévision
        Loi n°72-553 du 3 juillet 1972 et loi n°74-696 du 7 août 1974
      Usage de la langue française
        Imposition de l'anglais comme langue de travail chez Air France
        Maintien de la place du français dans le monde
    Fiscalité et équité sociale
      Taxes et contributions
        Taxe de publicité foncière
        Contribution des communes au fonds d'amortissement des charges d'électrification
          Différence de traitement entre communes rurales et urbaines
      Dégrèvements et exonérations
        Dégrèvement de la taxe d'habitation pour les plus de 65 ans
          Conditions d'éligibilité [revenus, valeur locative]
          Proposition de déductibilité de la taxe des revenus
      Successions et politique familiale
        Régime fiscal des testaments-partages
          Droit fixe vs droit proportionnel en ligne directe
          Incohérence fiscale pénalisant les familles
    Gestion des collectivités locales
      Péréquation financière
        Dotations pour les petites communes
        Inégalités entre communes de plus ou moins 2000 habitants
      Électrification et fonds d'amortissement
        Contribution des régies électriques communales
        Demande d'études pour corriger les anomalies
    Éthique et incompatibilités parlementaires
      Cas des députés exerçant des fonctions médicales
        Contradiction avec la décision du Conseil constitutionnel [1966]
        Exemple du député médecin-chef d'un hôpital départemental
      Respect des règles d'incompatibilité
        Nécessité de clarifier les situations conflictuelles
```
