---
source_file: 5-qst-1975-03-01.pdf
page_number: 8
total_pages: 32
total_images: 0
document_title: Journal Officiel de la République Française - Débats Parlementaires
language: fr
document_type: procès-verbal
---

culier, il appelle son attention sur le cas suivant: un soldat de la classe 1913 a bénéficié en 1916, après quatorze mois de présence au front, d'une permission de vingt et un jours. Ago a l'ímeuse de vingt ans et père de trois enfants en bas âge, l'intéressé n'a rejoint son unité qu'après une absence de 124 jours. Condamné pour ce fait à un an de prison avec sursis, la sanction a été effacée par voie d'amnistie mais la faute initiale, imputable à un défaut de jeunesse, exclut a vie cette personne du droit a la retraite d'ancien combattant. Or, pendant la dernicre guerre et alors qu'il était libéré de toute obligation militaire, l'intéressé n'a pas hésité à s'engager dans la Résistance et il s'est vu attribuer à ce titre un certificat national et la carte de combattant volontaire de la Révistance. Ces pièces officielles, bien qu'attestant le caractère circonstanciel de l'irregularité commise au cours de la guerre 1914-1918, ne suffisent pas a ouvrir droit à la retraite du combattant pourtant méritée en l'espèce à deux reprises. Cette situation est d'autant plus insupportable que les personnes convaincues d'indignité nationale pour avoir collaboré avec l'occupant ont pu continuer à percevoir la retraite du combattant aprés avoir été amnistiées. Le fait d'avoir apporté un concours actif a l'ennemi mérite ainsi l'indulgence alors que la faute vétielle d'un jeune homme rejoignant le front tardivement reste sanctionnée à vie, même si la conduite ultérieure a levé le moindre doute sur le patriotisme de l'intéressé. L'injustice de la situation appelle une mesure de clémence d'autant plus urgente que les derniers survivants de la guerre de 1914-1918, même s'ils ont commis une faute légère, ont bien droit, cinquante-sept ans plus tard, à la reconnaissance de la patrio.

Information et publicité (crédits affectés en 1974).
17431. - $1^{\text {er }}$ mars 1975. - M. Robert-André Vivien demande à M. le secrétaire d'Etat aux anciens combattants de lui indiquer quels sont les mayens en crédits et en personnel que ses services ont affectés à des tâches d'information en 1974, en précisant la répartition entre l'information internr. l'information externe et éventuellement la publicité dans la presse écrite, à la radio et à la télévision.

Retraite du combattant (uniformité du taux appliqué en France métropolitaine et outre-mer et à l'étranger).
17466. - $1^{\text {er }}$ mars 1975. - M. Robert Pabre expose à M. le secré. taire d'Etat aux anciens combattants que les anciens combattants résidant en France perçoivent la retraite du combattant à l'indice 9 à l'áge de soixante-cinq ans, alors qu'en application de l'article 99 ( $1^{\text {er }}$ de la loi $\mathrm{n}^{\circ} 56-780$ du 4 août 1956, confirmé par l'article 21 de l'ordonnance du 30 décembre 1958, les anciens combattants domiciliés à l'étranger bénéficient de la retraite du combattant à l'indice 23 à partir de l'áge de soixante-cing ans et à soixante ans en Alzate. Maroc, Tunisie et dans les départements et pays d'outremer. Il lui demande en conséquence s'il n'envisage pas, afin que cesse cette discrimination choquante, de prendre toutes dispositions nécessaires pour que les anciens combattants résidant en France aient les mêmes avantages que ceux fixés à l'étranger et dans les départements et pays précités.

## COMMERCE ET ARTISANAT

Information et publicité (crédits affectés en 1974).
17432. - $1^{\text {er }}$ mars 1975. - M. Robert-André Vivien demande à M. le ministre du commerce et de l'artisanat de lui indiquer quels sont les moyens en crédits et en personnel que ses services ont affectés à des tâches d'information en 1974, en précisant la répartition entre l'information interne, l'information externe et, éventuellement, la publicité dans la presse écrite, à la radio et à la télévision.

## COMMERCE EXTERIEUR

Information et publicité (credits affectés en 1974).
17433. - $1^{\text {er }}$ mars 1975. - M. Robert-André Vivien demande à M. le ministre du commerce extérieur de lui indiquer quels sont les moyens en crédits et en personnel que ses services ont affecté à des tâches d'information en 1974, en précisant la répartition entre l'information interne, l'information externe et éventuellement la publicité dans la presse écrite, à la radio et à la télévision.

## COOPERATION

Information et publicité (crédits affectés en 1974).
17434. - $1^{\text {er }}$ mars 1975. - M. Rubert-André Vivien demande a M. le ministre de la coopération de lui indiquer quels sont les moyens en crédits et en personnel que ses services ont affecté à des tâches d'information en 1974, en précisant la répartition entre l'information interne, l'information externe et, éventuellement, la publicité dans la presse écrite, à la radio et à la télévision.

## CULTURE

Monuments historiques (sauvegarde du château de Bagnac
à Saint-Bonnet-de-Bellec (Haute-Vienne) 1.
17354. - $1^{\text {er }}$ mars 1975. - M. Rigout attire l'attention de M. le secrétaire d'Etat à la culture sur la nécessité de sauvegarder le château de Bagnac situé sur le territoire de la commune de Saint-Bonnet-de-Bellec (Haute-Vienne). Cet édifice représente un intérêt architectural historique et touristique évident et reconnu. Il est actuellement en purit. Le deusier est soumis à la commission supérieure des monuments historiques. Il lui demande quelles décisions il compte prendre pour répondre aux demandes formulées par les associations de sauvegarde: société nationale pour la protection des paysages, sites et monuments et ligue urbaine et rurale, qui ont réclamé que des mesures urgentes soient prises afin d'assurer la nécessaire sauvegarde de ce patrimoine culturel.

Architectes (compétences des architectes des bâtiments de France en matière de permis de construire).
17436. - $1^{\text {er }}$ mars 1975. - M. de Poulpiquet rappelle a M. le secrétaire d'Etat à la culture que les architectes des bâtiments de France sont appelés à donner un avis sur la délivrance des permis de construire lorsqu'il s'agit de constructions à édifier dans un périmètre protégé. Il lui expose qu'une décision de refus a été prize par l'un d'eux qui a opposé au demandeur l'argument suivant: «reci,ercher un terrain dont la constructibilité n'aille pas à l'encontre de l'exploitation normale des fonds ruraux. A cet effet, la recherche se portera à proximité immédiate du bourg et des constructions existantes. Les raisons invoquées dans ce refus ne relèvent manifestement pas des attributions d'un architecte des bâtiments de France. C'est pourquoi il lui demande de bien vouloir inviter les fonctionnaires en cause à donner leur avis uniquement en fonction des attributions qui sont les leurs et non à partir de considérations qui ne relèvent pas de leur compétence.

Information et publicité (crédits affectés en 1974).
17435. - $1^{\text {er }}$ mars 1975. - M. Robert-André Vivien demande à M. le secrétaire d'Etat à la culture de lui indiquer quels sont les moyens en crédits et en personnel que ses services ont affecté à des tâches d'information en 1974, en précisant la répartition entre l'information interne, l'information externe et, éventuellement, la publicité dans la presse écrite, à la radio et à la télévision.

## DEFENSE

Médailles et décorations (attribution de la croix de chevalier de la Légion d'honneur à certains anciens combattants de la guerre 1939-1945).

17216. - $1^{\text {er }}$ mars 1975. - M. Stehlin demande à M. le ministre de la défense si le Gouvernement n'envisage pas de déposer un projet de loi en vue de l'attribution de la croix de chevalier de la Légion d'honneur, à l'occasion du trentième anniversaire de l'armistice du 8 mai 1945, au bénéfice des anciens combattants médaillés militaires et justifiant en outre de quatre titres de guerre: citations ou blessures acquises au cours de la guerre 1939-1945.

Service national (décés du soldat Serge Camier
sureenu au cours de manoeuvres au camp de Sissonne (AisneJ).
17240. - 11 mars 1975. - M. Le Meur attire l'attention de M. le ministre de la défense sur les circonstances tragiques de la mort d'un jeune soldat du contingent Serge Camier. Au cours des manoeuvres de la 15 ' brigade de Verdun, manœuvres qui ont actuellement lieu au camp national de Sissonne (02), ce soldat de 2' classe, du 159' B. I. de Verdun, âgé de vingt ans, a été écrasé par un AMX 30 ,du $2^{\circ}$ régiment de chasseurs portés. La mort a été