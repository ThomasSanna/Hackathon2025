---
source_file: 5-qst-1975-03-01.pdf
page_number: 2
total_pages: 32
total_images: 0
document_title: Journal Officiel de la République Française - Débats Parlementaires
language: fr
document_type: procès-verbal
---

## QUESTIONS ÉCRITES

(Art. 139 et 133 du réglement.)

## Article 139 du règlement:

- 1. Les questions écrites sont rédigées, notifiées et publiées dans les conditions fixées par l'article 133. En outre, elles ne doivent contenir aucune imputation d'ordre personnel o l'égard de tiers nommément désignés;
- 2. Les réponses des ministres doivent être publiées dans le mois suivant la publication des questions. Ce délai ne comporte aucune interruption;
- 3. Dans ce délai, les ministres ont toutefois la faculté soit de déclarer par écrit que l'intérêt public ne leur permet pas de répondre, soit, à titre exceptionnel, de demander, pour rassembler les éléments de leur réponse, un délai supplémentaire qui ne peut excéder un mois;
- 4. Lorsqu'une question écrite n'a pas obtenu de réponse dans les délais exercés, son auteur est incité par le président de l'Assemblée à lui faire connaitre s'il entend ou non la convertir en quesgion orale. Dans la négative, le ministre compétent dispose d'un délai supplémentaire d'un mois;
- 5. Dans le cas où la question écrite est transformée en question orale, celle-ci prend rang dans les conditions prévues au dernier alinéa de l'article 133;
- 6. Font l'objet d'un rappel publié au Journal officiel les questions écrites auxquelles il n'a pas été répondu dans les délais prévus aux alinéas 2, 3 et 4 du présent article;
- 7. Le texte des questions écrites est reproduit dans les rappels. Il est communiqué aux auteurs des questions en même temps que le rappel leur est notifié. n


## QUESTIONS ECRITES

REMISES A LA PRESIDENCE DE L'ASSEMBLEE NATIONALE

## PREMIER MINISTRE

Service nutionel (mexures d'amnistie en faveur des objecteurs de conscience insoumis a l'office national des forêts).
17208. - $1^{\text {er }}$ mars 1975. - M. Villon attire l'attention de M. le Premier ministre sur la situation de plusieurs centaines d'objecteurs de conscience qui, ayant été reconnus comme tels par la commission juridictionnelle, avaient refusé d'accomplir le service civil dans le cours de l'office national des forêts pour ne pas se soumettre au décret du 17 août 1972 qui leur supprime pendant les deux ans de service les droits civiques les plus élémentaires et qui ont donc été considérés comme insoumis, même lorsqu'ils ont accompli leur service pendant deux ans volontairement au sein d'ussociations civiles d'intérêt général agréées avant juin 1972 pour les recevoir. Bien que le délit d'insoumission ait été amnistié par la loi du 16 juillet 1974, leur situation reste incertalye en ce qui concerne leurs obligations de service. Aussi il lui demande de prendre des mesures: $1^{\circ}$ afin que la situation des jeures gens insoumis à l'O.N.F. soit régularisée et qu'ils soient considérés comme ayant accompli leurs obligations; $2^{\circ}$ afin que soient abrogés les articles R. 83, R. 84 et R. 85 du code du service national et remplacés par des dispositions respectant les droits de citoyen; $3^{\circ}$ afin de rétablir la possibilité d'accomplir le service civil dans le cadre d'associations civiles créées selon la loi de 1901 et prêtes à recueillir les objecteurs de conscience pour accomplir des tâches d'intérêt public ou de solidarité humaine.

## Radiodiffusion et télévision nationales

(réglementation du droit de réponse à la radio et à la télévision).
17229. - $1^{\text {er }}$ mars 1975. - M. Beulay rappelle à M. le Premier ministre que, en vertu de l'article 8 de la loi $n^{\circ} 72-553$ du 3 juillet 1972, maintenu en vigueur par l'article 34 de la loi $n^{\circ} 74-696$ du 7 août 1974, un décret en Conseil d'Etat doit déterminer les conditions dans lesquelles pourra s'exercer le droit de réponse a la radio et à la télévision. Il lui demande de bien vouloir lui faire connaitre s'il envisage, après plus de trente-deux mois d'attente, de faire prochainement paraître le décret d'application précité ou s'il a définitivement renoncé à instituer un droit de réponse, contrairement au voie émis par le Parlement à ce sujet.

Transports aériens (usage exclusif de l'anglais
comme langue de travail des nacigants d'Air France).
17231. - $1^{\text {er }}$ mars 1975. - M. Kalinsky attire l'attention de M. le Premier ministre sur la question écrite $n^{\circ} 15449$ adressée à M. le secrétaire d'Etat à la culture et publiée au Journal officiel du 11 décembre 1974 concernant la politique persévérante de la compagnie Air France tendant à imposer à ses navigants l'usage de l'anglais comme langue de travail exclusive. Plus de deux mois après sa publication, cette question écrite demeure sans réponse. Il lui demande comment il entend, conformément à ses déclarations du 7 février, a maintenir à la langue française sa place dans le monde de demain * et s'il ne pense pas que le transport aérien fait partie du monde de demain.

Urbanisme (revision du schéma directeur d'aménagement urbain de Melun-Sénart).
17271. - $1^{\text {er }}$ mars 1975. - M. le Premier ministre ayant exposé au cours de son allocution, lors de l'inauguration de l'hôtel de ville de Vélizy-Villacoublay, son intention de faire procéder à la réunion du schéma directeur d'aménagement et d'urbanisme de plusieurs villes importantes, M. Alain Vivien attire son attention sur la distorsion croissante entre les objectifs du S.D. A. U. de Melun-Sénart et les réalités de l'élaboration de cette ville nouvelle. Handicapée au départ, tant par la trop grande proximité de la ville nouvelle d'Evry (à cinq kilomètres) que par sa propre dispersion (trois secteurs isolés par un pré-carré réputé incombractible), Melun-Sénart ne connait guère, à l'heure actuelle qu'une poussée excessive d'urbanisation sans infrastructure (ni le lycée, ni le C.E.T., ni le C.H.U., ni l'hôpital de Combs-la-Ville n'ont été réalisés) et sans emploi (les zones industrielles prévues sont pratiquement vides ou, pire, non initiées). Alors qu'au cours des séances d'élaboration du S.D.A. U., il avait été entendu que, pour dix personnes d'âge actif nouvellement installées, on créerait de sept à huit emplois nouveaux, la proportion réelle s'établit aux environs de 0,1 emploi pour 10 nouveaux habitants en âge de travailler. Encore faut-il comprendre, pour atteindre ce taux, les emplois existant à Melun (hors ville nouvelle) qui se sont déconcentrés en ville nouvelle, notamment à Vart-Saint-Denis, et n'ont créé aucun débouché nouveau, mis à part quelques emplois de gardiennage ou de maintenance. Il attire d'autre part l'attention de M. le Premier ministre sur le fait que, sur les assurances de la mission d'aménagement et sous la pression de certaines personnalités politiques, la plupart des communes comprises dans le S.D.A. U. ont engagé des crédits importants. Lorsque les différés d'amortissement seront parvenus à leur terme, il y a tout lieu de penser que l'endettement des collectivités locales sera tel que les populations, récemment ou anciennement installées, supporteront un surcroît fiscal d'autant plus considérable que l'absence d'implantation industrielle ne permettra pas d'en minorer le poids. Compte tenu du fait que le S.D.A. U. de Melun-Sénart n'est pas approuvé, il lui demande: $1^{\circ}$ s'il ne lui paraitrait pas opportun d'en décider la revision; $2^{\circ}$ de minorer l'urbanisation envisagée et d'en lire strictement la réalisation au remplissage des zones industrielles prévues; $3^{\circ}$ d'accorder, dans l'immédiat, une majoration sensible des crédits aux trois syndicats communautaires d'aménagement pour rattraper les retards observés en matière d'infrastructure, scolaire notamment.

Gouvernement (information des parlementaires sur les visites de membres du Gouvernement dans leurs circouscriptions).
17272. - $1^{\text {er }}$ mars 1974. - M. Alain Vivien expose à M. le Premier ministre que par question écrite en date du 10 janvier 1975 il s'élevait contre le manque de courtoisie de certains ministres à l'égard de parlementaires de l'opposition lorsque, venant en visite officielle dans leur circonscription, ils n'en informent point les députés ou sénateurs précités. Or M. le ministre de la qualité de la vie s'est rendu récemment à Melun pour y visiter une usine de chauffage d'H. L. M. utilisant l'énergie géothermique. Il s'est fait accompagner du préfet, conférant ainsi un caractère officiel à son séjour, et du cadre de la ville, ancien député de Melun. Il lui demande s'il ne lui parait pas regrettable que soient maintenues de telles pratiques, vestiges de périodes gouvernementales révolues, si elles ne lui paraissent pas en contradiction avec les intentions du Gouvernement et le souci de concertation qu'il manifeste en plusieurs occasions.

Incompatibilités parlementaires
(député médecin-chef d'un hôpital départemental).
17274. - 1er mars 1975. - M. Jean-Pierre Cet appelle l'attention de M. le Premier ministre sur la contradiction existant entre la décision $n^{\circ} 66-11$ du 8 juillet 1966 du Conseil constitutionnel (relative à l'examen de l'incompatibilité des fonctions de médecin-