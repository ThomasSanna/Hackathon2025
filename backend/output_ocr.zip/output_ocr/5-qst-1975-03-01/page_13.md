---
source_file: 5-qst-1975-03-01.pdf
page_number: 13
total_pages: 32
total_images: 0
---

d'emive en vigueur de la loi du 23 decembre 1964, soit jusqu'à la date de leur transformati n inclusivement; 2' qu'aucune part ou action n'aura été cédée à titre onéreux à une persenne autre qu'un associé initial jusqu'à la date de transformation inclusivement. Aus termes d'un acte notarié en date du 31 mars 1972, les assercles ont refendu les statuts de la société en vue de la placer sous le régime de l'article 28 de la loi du 23 décembre 1964. Il est précisé dans l'acte, pour autant que de hesoin, que jusqu'à cette transformation, la sctité n'avait effectué aucune vente d'immeuble et que les associés étaient tous les associés d'origine. Immediatement après cette transformation, certains associés ont cédé leurs parts moyennant un prix éral à la valeur nominale des parts. L'imperieur des impôts prétend opérer un redressement et imposer la société civile à l'impôt sur les sociétes au motif que l'article précise que pour bénéficier du régime prévu par la loi du 23 décembre 1964, ces sociétés ne doivent avoir procédé à aucune vente d'immeuble ou de fraction d'immeuble et à aucune cession de part ou d'action. Jusqu'à la date de la transformation de la sociéte inclusivement. Il semble que le mot "inclusivement" veuille signifier qu'il n'y a eu aucune cession jusqu'au moment de la transformation, ce qui a d'ailleurs été précisé dans l'acte de transformation sue-indiqué. En conséquence, il lui demande s'il peut confirmer cette interprétation.

Tare d'habitation (distorsions résultont de la prise en compte de la nouvelle valeur locutive pour les logements arheats après le 1" janvier 1974).
17318. - $1^{\text {er }}$ mars 1975. - M. Crespin pose à M. le ministre de l'économie et des Finances la question suivante : a Le régime des nouveaux impôts directs locaux dont la réforme a été posée par l'ordonnance $\mathrm{n}^{\circ} 59-108$ du 7 janvier 1959 a été mis en application - pour partie seulement d'ailleurs - à compter du $1^{\text {er }}$ janvier 1974. La loi $n^{\circ} 73-1229$ du 31 décembre 1973 en a défini les modalités et c'est par la mise en recouvrement des premiers avérimements concernant la taxe d'habitation, qu'il est possible d'en mesurer les conséquences. L'article $12\left(1^{\circ}\right)$ de la lui précitée a prévu un régime transitoire tendant à atténuer les effets de ces nouvelles dispositions. Celuici consiste à étaler sur cinq ans le passage des anciennes aux nouvelles bases d'imposition. Mais le texte législatif stipule que les constructions achevées après le $1^{\text {er }}$ janvier 1974 seront immédiatement imposées d'après leur valeur locative nouvelle. Cette mesure entraîne une distorsion importante - et juste inadmissible pour les contribuables qui n'ont pu se procurer de logement avant le début de l'année écoulée. La différence dans le montant de l'imposition se traduit par un écart de 1 à 5 au détriment de nouveaux logements qui ont d'ailleurs souvent l'inconvénient de se trouver au milieu de chentiers non terminés, dans un environnement contrastant avec l'avantage estimé par la loi. Cette mesure est particulièrement chouante dans les quartiers comportant des constructions H. L. M. Ce sont les attributaires qui ont dû attendre le plus longtemps pour jouir d'un nouveau logement rigoureusement conforme dans un grand nombre de cas à ceux affectés préalablement au 31 décembre 1973 - qui supportent injustement une charge paraissant disproportionnée par comparaison à la valeur locative du local dont ils ont la jouissance. Il apparaît à la lumière de l'expérience, qu'un nouveau texte devrait rapidement mettre fin à cette anomalie. C'est pourquoi M. Crespin demande à M. le ministre de l'économie et des finances de faire procéder à l'analyse de cette importante question et, de lui faire connaitre les solutions qui pourront y porter remède. -

## Entreprises

(consolidation d'une part des découverts bancaires des P. M. E.).
17323. - $1^{\text {er }}$ mars 1975. - M. Godon appelle l'attention de M. le ministre de l'économie et des finances sur les difficultés souvent très graves que connaissent les petites et moyennes entreprises parfaitement saines en raison de la conjecture économique. Il serait désastreux pour l'économie française qu'on nomme important de ces entreprises viennent à disparaître à cause de ces difficultés que l'on peut raisonnablement considérer comme provisoires. Il lui demande de bien vouloir faire mettre à l'étude un projet tendant à aider les entreprises en cause, projet qui pourrait consister à conseiller auprès des banques la moitié du découvert que celles-ci peuvent avoir, consolidation qui pourrait être étalée sur un délai de cinq à sept ans à un taux modéré (par exemple actuellement de l'ordre de 10 p .100 ).

Participation des travailleurs (application du rapport salaires-valeur ajoutée comme élément de calcul).
17325. - $1^{\text {er }}$ mars 1975. - M. Hardy rappelle à M. le ministre de l'économie et des finances que le calcul de la participation des salariés aux fruits de l'exponaion des entreprises, tel qu'il est déterminé par l'ordonnance $\mathrm{n}^{\circ} 67-893$ du 17 août 1967, prévoit l'application d'un rapport salaires/valeur ajoutée. La définition de la valeur ajoutée
est donnée par l'article 2 du décret $n^{\circ} 67-1112$ du 19 décembre 1967 qui précise, en particulier, que les éléments à retenir sont différents postes (u compte d'exploitation générale et le "bénéficit d'exploitation " Par ailleurs, l'instruction de la D. G. L. du 30 mai 1968 définissant les éléments du calcul ne donne aucun commentaire sur ce "Punéficé d'exploitation ". Il lui demande en conséquence si, dans le cas expriyicnel mais possible où une société dégage une perie d'exploitation mais un résultat fiscal bénéficiaire permettant une participation, il convient, dans le calcul de la "valeur ajoutée ". soit de se baser sur la notion de "bénéficé d'exploitation " et donc ne reienir que les autres éléments (frais de personnel, eie.) et ne rien compter pour le poste "bénéficé d'exploitation ", soit d'aller jusqu'à la notion de " résultat d'exploitation " et donc de retrancher des autres éléments la perte d'exploitation.
T. V. A. (denrées utilisées pour la nourriture de la famille et du personnel des restaurateurs).
17327. - $1^{\text {er }}$ mars 1975. - M. Jacques Legendre rappelle à M. le ministre de l'économie et des finances que, en matière de fiscalité concernent la nourriture rétrocédée un personnel des restaurants ainsi qu'à la famille des restaurateurs, la T. V. A. doit être acquittée au taux intermédiaire de 17,60 p. 100 alors que ce taux ne s'applique, dans le décompte normal, qu'aux denrées liquides et que les denrées solides ne sont par contre assujetties qu'au taux de 7 p. 100. L'administration fait état de l'impossibilité, pour le restaurateur, de déterminer les achats effectués en vue de nourrir sa famille et son personnel pour justifier la détermination du taux unique de la T. V. A. à appliquer. Compte tenu de ce que la T. V. A. doit s'appliquer seulement sur la différence entre le prix de vente et le prix de revient, c'est-à-dire sur le montant du bénéfice brut, il lui demande s'il n'estime pas équitable de reconduiférer les règles en vigueur pour le paiement de la T. V. A. sur les denrées utilisées pour la nourriture du persconel des restaurateurs en adoptant une des solutions préconisées ci-dessous : soit acquitter le prix de la taxe sur la valeur des repas comme il est procédé actuellement en matière de sécurité sociale, soit ne pas acquitter la T. V. A. mais procéder au revirement de la taxe précédemment deduite. La deuxième solution paraît être la plus rationnelle et le remboursement de la T. V. A. pourrait être appliqué selon les critères suivants : taux réduit de 7 p. 100 sur 80 p. 100 de la dépense engagée représentant forfaitairement la nourriture solide; taux de 17,60 p. 100 sur les 20 p. 100 restant, représentant une estimation forfaitaire des boissons.

## Commeryants et artisans

(décote de T. V. A. des artisans associés).
17328. - $1^{\text {er }}$ mars 1973. - M. Le Theule rappelle à M. le ministre de l'économie et des finances que sous réserve de remplir certaines conditions et notamment être redevables pour une année d'un montant net de T. V. A. inférieur à 500 francs ou 13500 francs les artisans peuvent bénéficier de la décote, générale dans le premier cas, spéciale dans le second cas. Si deux artisans ou plus décident de travailler en commun soit en société de fait, soit en société en nom collectif, les plafonds ci-dessus s'appliquent alors à la personne morale de droit ou de fait et non plus à chacun d'eux. Il en résulte que les artisans qui, suivant la tendance actuelle qui les y encourage, s'organisent et se mettent à travailler en commun, peuvent se trouver lourdement pénalisés. Il lui expose à cet égard les deux exemples suivants:
$1^{\circ}$ Soit deux artisans indépendants:
Pour chacun d'eux T. V. A. due.
10000 F.
Net à payer après dérote spéciale.
7119
Montant de la décote spéciale.
2881 F .
Si ces artisans exploitent en société de fait, T. V. A.
due: $10000 \times 2=$
20000 F .
T. V. A. nette à payer.
20000
Decote
néant.
$2^{\circ}$ Soit deux artisans indépendants:
Pour chacun d'eux T. V. A. due.
7001 F.
Net à payer après décote spéciale.
3255
Montant de la décote spéciale.
3745 F .
Si ces artisans exploitent en société de fait T. V. A.
due: $7000 \times 2=$
14000 F .
T. V. A. nette à payer
14000
Décote
néant.
Pour tenir compte des situations de ce genre qui sont regrettables il lui demande, toutes autres données restant inchangées, que les chiffres limites soient appréciés en fonction du nombre des artirans associés.