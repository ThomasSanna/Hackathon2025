---
source_file: 5-qst-1975-03-01.pdf
page_number: 1
total_pages: 32
total_images: 0
document_title: Journal Officiel de la République Française - Débats Parlementaires
language: fr
document_type: procès-verbal
summary: Le document est un compte rendu intégral des séances de l'Assemblée Nationale
  française, daté du 1er mars 1975. Il inclut des questions écrites remises à la présidence
  de l'Assemblée Nationale et des réponses des ministres aux questions écrites. Les
  sujets abordés incluent des questions sur la politique agricole, la radiodiffusion
  et la télévision nationales, les anciens combattants, les fonctionnaires, les accidents
  du travail, les affaires étrangères, l'agriculture, les anciens combattants, le
  commerce et l'artisanat, le commerce extérieur, la coopération, la culture, et la
  défense.
key_points:
- Questions écrites remises à la présidence de l'Assemblée Nationale.
- Réponses des ministres aux questions écrites.
- 'Sujets abordés: politique agricole, radiodiffusion et télévision nationales, anciens
  combattants, fonctionnaires, accidents du travail, affaires étrangères, agriculture,
  anciens combattants, commerce et artisanat, commerce extérieur, coopération, culture,
  défense.'
- Détails spécifiques sur les questions et réponses concernant divers aspects de la
  politique et de l'administration française.
authors: []
date: 1er Mars 1975
organizations:
- Assemblée Nationale
- Journal Officiel de la République Française
---

# JOURNAL OFFICIEL DE LA RÉPUBLIQUE FRANÇAISE 

## DÉBATS PARLEMENTAIRES

## ASSEMBLÉE NATIONALE

## COMPTE RENDU INTEGRAL DES SEANCES

Abonnements a l'Edition des DEBATS DE L'ASSEMBLEE NATIONALE : FRANCE ET OUTREMER : 22 F ; ETRANGER : 40 F (Compte chèque postal: 9063-13, Paris.)

DIRECTION, REDACTION ET ADMINISTRATION
20, Rue Desaix, 78732 Paris CEDEX 15.

Téléphune
( Renseignements : 579-01-95
Administration: 578-61-39
Le bureau de vente est ouvert tous les jours, sauf le dimanche et les jours fériés, de 8 h 30 a 12 h et de 13 h a 17 h.

## CONSTITUTION DU 4 OCTOBRE 1958

## 5* Législature

## QUESTIONS

REMISES A LA PRESIDENCE DE L'ASSEMBLEE NATIONALE

## ET

## RÉPONSES DES MINISTRES AUX QUESTIONS ÉCRITES

## QUESTIONS ORALES AVEC DÉBAT

(Art. 133, 134, 135 et 137 du règlement.)

Politique agricole (organisation d'un débat parlementaire sur les mesures de sauvegarde).
17294. - 23 février 1975. - M. Rigout attire l'attention de M. le Premier ministre sur la gravité de la dégradation du revenu des agriculteurs. Si des mesures importantes ne sont pas prises rapidement pour remédier à cette situation, le potentiel productif agricole sera directement mis en cause. En 1974, le pouvoir d'achat agricole a balasé en moyenne de 15 p. 100. Compte tenu de
$\star$ (2 f.)

I'inflation, les prix fixés à Bruxelles pour la campagne 1975-1976 non seulement consacrent la dégradation intervenue en 1974, mais conduisent à une nouvelle aggravation pour 1975. Des mesures nationales complémentaires s'imposent donc pour compenser l'insuffisance des mesures commu^autaires. Dans ces conditions, il lui demande que l'Assemblée nationale, au cours d'un large débat, puisse délibérer et se prononcer dans les premiers jours de la session sur les mesures urgentes qui s'imposent et les conditions de leur application. Ces mesures soumises à la discussion et au vote de la représentation nationale devraient porter notamment sur trois objectifs essentiels: garantir une progression normale et suffisante du pouvoir d'achat des agriculteurs; aboutir à une meilleure organisation des marchés; permettre une augmentation du pouvoir d'achat intérieur et développer nos exportations de produits alimentaires.