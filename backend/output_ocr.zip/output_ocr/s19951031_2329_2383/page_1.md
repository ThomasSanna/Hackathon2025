---
source_file: s19951031_2329_2383.pdf
page_number: 1
total_pages: 8
total_images: 2
document_title: Compte Rendu Intégral
language: fr
document_type: procès-verbal
summary: Le document est un compte rendu intégral d'une séance du Sénat français tenue
  le 31 octobre 1995. La séance, présidée par M. Jean Faure, traite divers points
  à l'ordre du jour, notamment les candidatures à des organismes extraparlementaires,
  les plans de redressement du Crédit Lyonnais et du Comptoir des Entrepreneurs, et
  la nomination de membres d'organismes extraparlementaires. Le document inclut également
  des discussions sur des amendements et des votes sur divers articles de loi. Les
  principaux intervenants incluent M. Hervé Gaymard, secrétaire d'État aux finances,
  et M. Alain Lambert, rapporteur de la commission des finances.
key_points:
- Séance du Sénat française tenue le 31 octobre 1995.
- Présidence de M. Jean Faure.
- Discussion des candidatures à des organismes extraparlementaires.
- Plans de redressement du Crédit Lyonnais et du Comptoir des Entrepreneurs.
- Nomination de membres d'organismes extraparlementaires.
- Discussion et vote sur divers amendements et articles de loi.
- Interventions de M. Hervé Gaymard et M. Alain Lambert.
authors:
- M. Jean Faure
- M. Hervé Gaymard
- M. Alain Lambert
date: 31 octobre 1995
organizations:
- Sénat français
- Crédit Lyonnais
- Comptoir des Entrepreneurs
images:
- id: img-0.jpeg
  filename: page1_img1.jpg
  image_type: logo
  title: Logo du Sénat - Débats Parlementaires
  description: Logo du Sénat français avec la mention 'Débats Parlementaires'.
  detailed_description: L'image montre le logo officiel du Sénat français. Le mot
    'SÉNAT' est écrit en grandes lettres majuscules, avec un style de police qui rappelle
    les inscriptions classiques. En dessous, en plus petites lettres, il y a la mention
    'DÉBATS PARLEMENTAIRES', indiquant que le logo est associé aux discussions et
    débats qui se déroulent au sein du Sénat.
- id: img-1.jpeg
  filename: page1_img2.jpg
  image_type: logo
  title: Logo du Journal Officiel
  description: Logo du Journal Officiel de la République française
  detailed_description: Le logo représente les lettres 'JO' stylisées en noir et blanc.
    En dessous, le texte 'JOURNAL OFFICIEL' est écrit en majuscules noires.
---

![[logo] - Logo du Sénat - Débats Parlementaires](images/page1_img1.jpg)

# JOURNAL OFFICIEL DE LA RÉPUBLIQUE FRANÇAISE 

DIRECTION DES JOURNAUX OFFICIELS
26, rue Desaix, 75727 PARIS CEDEX 15
![[logo] - Logo du Journal Officiel](images/page1_img2.jpg)

Standard
Renseignements
Télécopie

Standard
(16-1) 40-58-75-00
(16-1) 40-58-78-78
(16-1) 45-79-17-84

SESSION ORDINAIRE DE 1995-1996

## COMPTE RENDU INTÉGRAL

Séance du mardi 31 octobre 1995
( $12^{\mathrm{e}}$ jour de séance de la session)