---
source_file: s19951031_2329_2383.pdf
page_number: 2
total_pages: 8
total_images: 0
document_title: Compte Rendu Intégral
language: fr
document_type: procès-verbal
---

# SOMMAIRE 

## PRÉSIDENCE DE M. JEAN FAURE

1. Procès-verbal (p. 2332).
2. Candidatures à des organismes extraparlementaires (p. 2332).
3. Plans de redressement du Crédit Lyonnais et du Comptoir des Entrepreneurs. - Discussion d'un projet de loi (p. 2332).
Discussion générale : MM. Hervé Gaymard, secrétaire d'Etat aux finances; Alain Lambert, rapporteur de la commission des finances; Christian Poncelet, président de la commission des finances; Jean Huchon, Alain Richard, Gérard Larcher, Emmanuel Hamel.
M. le secrétaire d'Etat.

Clôture de la discussion générale.
M. le président de la commission.
4. Nomination de membres d'organismes extraparlementaires (p. 2353).

Suspension et reprise de la séance (p. 2353)

## PRÉSIDENCE DE M. YVES GUÉNA

5. Décès d'un ancien sénateur (p. 2353).
6. Prestation de serment d'un juge suppléant de la Haute Cour de justice (p. 2353).
7. Modification de l'ordre du jour (p. 2354).
8. Candidatures à des organismes extraparlementaires (p. 2354).
9. Plans de redressement du Crédit Lyonnais et du Comptoir des Entrepreneurs. - Suite de la discussion et adoption d'un projet de loi (p. 2354).

Question préalable (p. 2354)
Motion n 7 de $\mathrm{M}^{\text {me }}$ Hélène Luc. - MM. Robert Pagès, Alain Lambert, rapporteur de la commission des finances; Hervé Gaymard, secrétaire d'Etat aux finances; Claude Billard. - Rejet par scrutin public.

Article additionnel avant l'article $1^{\text {er }}$ (p. 2358)
Amendement $\mathrm{n}^{\circ} 8$ de M. Paul Loridant. - MM. Robert Pagès, le rapporteur, le secrétaire d'Etat. - Rejet.

Article $1^{\text {er }}$ (p. 2359)
Amendement $\mathrm{n}^{\circ} 9$ rectifié de M. Paul Loridant. MM. Claude Billard, le rapporteur, le secrétaire d'Etat, Alain Richard. - Rejet.
Adoption de l'article.
Article 2 (p. 2360)
Amendements $\mathrm{n}^{\text {os }} 10,11,12$ rectifié et 13 de M. Paul Loridant. - MM. Robert Pagès, le rapporteur, le secrétaire d'Etat. - Retrait de l'amendement $\mathrm{n}^{\circ} 10$; rejet des amendements $\mathrm{n}^{\text {os }} 11,12$ rectifié et 13 .

Adoption de l'article.
Article additionnel après l'article 2 (p. 2363)
Amendement $\mathrm{n}^{\circ} 14$ de M. Paul Loridant. - MM. Claude Billard, le rapporteur, le secrétaire d'Etat. - Rejet.

Article 3 (p. 2364)
Amendements $\mathrm{n}^{\text {os }} 1$ rectifié de la commission et 15 de M. Paul Loridant. - MM. le rapporteur, Robert Pagès, le secrétaire d'Etat. - Adoption de l'amendement $\mathrm{n}^{\circ} 1$ rectifié rédigeant l'article, l'amendement $\mathrm{n}^{\circ} 15$ étant devenu sans objet.

Article 3 bis (p. 2364)
Amendement $\mathrm{n}^{\circ} 16$ de M. Paul Loridant. - Devenu sans objet.
Adoption de l'article.
Article 4 (p. 2364)
Amendement $\mathrm{n}^{\circ} 17$ rectifié de M. Paul Loridant. - MM. Robert Pagès, le rapporteur, le secrétaire d'Etat. - Rejet.

Adoption de l'article.
Article 5 (p. 2365)
Amendement $\mathrm{n}^{\circ} 18$ rectifié de M. Paul Loridant. - MM. Robert Pagès, le rapporteur, le secrétaire d'Etat, Alain Richard. - Rejet.
Adoption de l'article.
Article additionnel avant l'article 6 (p. 2366)
Amendement n 19 de M. Paul Loridant. - MM. Ivan Renar, le rapporteur, le secrétaire d'Etat. - Rejet.

Article 6 (p. 2367)
Amendement n 20 de M. Paul Loridant. - MM. Robert Pagès, le rapporteur, le secrétaire d'Etat. - Rejet.
Adoption de l'article.
Article 7 (p. 2368)
Amendement n 21 de M. Paul Loridant. - Devenu sans objet.
Amendement n 22 de M. Paul Loridant. - MM. Robert Pagès, le rapporteur, le secrétaire d'Etat. - Rejet.
Adoption de l'article.
Article 8 (p. 2368)
Amendement $\mathrm{n}^{\circ} 23$ rectifié bis de M. Paul Loridant. MM. Robert Pagès, le rapporteur, le secrétaire d'Etat. Rejet.
Adoption de l'article.
Article 9 (p. 2369)
Amendement n 24 de M. Paul Loridant. - Devenu sans objet.
Adoption de l'article.
Article 10 (p. 2369)
Amendement n 25 de M. Paul Loridant. - Devenu sans objet.
Adoption de l'article.