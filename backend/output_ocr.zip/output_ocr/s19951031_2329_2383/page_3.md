---
source_file: s19951031_2329_2383.pdf
page_number: 3
total_pages: 8
total_images: 0
document_title: Compte Rendu Intégral
language: fr
document_type: procès-verbal
---

Article 11 (p. 2369)
Amendement $\mathrm{n}^{\circ} 26$ de M. Paul Loridant. - Devenu sans objet.
Adoption de l'article.
Article 12 (p. 2369)
M. le rapporteur. - Amendement $\mathrm{n}^{\circ} 27$ de M. Paul Loridant. - Devenu sans objet.
Amendement $\mathrm{n}^{\circ} 2$ rectifié de la commission. - MM. le rapporteur, le secrétaire d'Etat. - Adoption.
Adoption de l'article modifié.
Articles 13 et 14. - Adoption (p. 2370)
Article 15 (p. 2371)
Amendement n 28 de M. Paul Loridant. - MM. Robert Pagès, le rapporteur, le secrétaire d'Etat. - Rejet.
Adoption de l'article.
Article additionnel après l'article 15 (p. 2371)
Amendement $\mathrm{n}^{\circ} 3$ de la commission. - MM. le rapporteur, le secrétaire d'Etat. - Adoption de l'amendement insérant un article additionnel.

Article 16. - Adoption (p. 2371)
Article 17 (p. 2371)
Amendement $\mathrm{n}^{\circ} 4$ de la commission. - MM. le rapporteur, le secrétaire d'Etat. - Adoption.
Adoption de l'article modifié.
Article 18 (p. 2371)
Amendement n 29 de M. Paul Loridant. - Devenu sans objet.
Adoption de l'article.

Article 19 (p. 2372)
Amendements $\mathrm{n}^{\circ} 6$ de M. Jean-Jacques Hyest et 5 de la commission. - MM. Jean-Jacques Hyest, le rapporteur, le secrétaire d'Etat, Alain Richard, Michel Caldaguès, Emmanuel Hamel. - Retrait de l'amendement $\mathrm{n}^{\circ} 6$; adoption de l'amendement $\mathrm{n}^{\circ} 5$ rédigeant l'article. "

Vote sur l'ensemble (p. 2374)
MM. Michel Caldaguès, James Bordas, Claude Billard, Alain Richard.

Adoption du projet de loi.
10. Nomination de membres d'organismes extraparlementaires (p. 2376).
11. Communication de l'adoption définitive de propositions d'actes communautaires et rectificatif à une précédente communication (p. 2376).
12. Reprise d'une proposition de loi (p. 2377).
13. Dépôt de propositions d'actes communautaires (p. 2377).
14. Dépôt d'un avis (p. 2377).
15. Ordre du jour (p. 2377).