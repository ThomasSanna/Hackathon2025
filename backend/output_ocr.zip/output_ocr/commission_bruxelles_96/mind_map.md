# Carte Mentale - Compte rendu intégral de la séance inaugurale de l'Assemblée de la Commission Communautaire Française (20 octobre 1995)

```mermaid
mindmap
  root((Séance inaugurale de l'Assemblée de la Commission Communautaire Française (20 octobre 1995)))
    Organisation et fonctionnement institutionnel
      Nomination du Bureau
        Candidatures proposées
          Président : R. Hotyat
          Vice-présidents : S. de Patoul, S. de Lobkowicz, G. Désir
        Secrétaires : M. Daïf, P. Smits, D. Grimberghs, P. Galand
      Approbation de l'ordre du jour
        Points abordés : pages 3 à 6
        Procédure d'approbation
      Constitution de l'Assemblée
        Règles de proclamation sans scrutin
        Applaudissements et prise de fonction
    Discours et allocutions
      Allocution du Président
        Importance de la démocratie
        Défis actuels des institutions bruxelloises
      Interventions des élus
        M. Bernard Clerfayt : proposition des candidatures
        Autres élus : questions et débats
    Processus législatif et propositions
      Dépôt de propositions de décret
        Commission consultative bruxelloise du tourisme
        Service de médiation conjoint
      Discussions et prises en considération
        Liquidation des subsides
        Réallocations budgétaires
      Questions écrites au Collège
        Thèmes abordés : gestion budgétaire
        Réponses attendues
    Gestion budgétaire et financements
      Réallocations budgétaires
        Arrêts annoncés
        Impact sur les subsides
      Solidarité intercommunautaire
        Tensions Bruxelles-Wallonie
        Rôle des socialistes bruxellois
      Cour des comptes et contrôle financier
        Vérification des comptes
        Transparence budgétaire
    Coopération et tensions intercommunautaires
      Relations Bruxelles-Wallonie
        Risque de rupture de solidarité
        Processus de refinancement de la Communauté française
      Médiation institutionnelle
        Rôle des services de médiation
        Gestion des conflits
```
