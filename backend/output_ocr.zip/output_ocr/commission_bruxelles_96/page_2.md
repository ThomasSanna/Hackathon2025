---
source_file: commission_bruxelles_96.pdf
page_number: 2
total_pages: 8
total_images: 0
document_title: Compte Rendu Intégral de la Séance du 20 Octobre 1995
language: fr
document_type: procès-verbal
---

# Interpellations 

de Mme Evelyne Huytebroeck (aides financières de la CCF) à M. Hervé Hasquin, Président du Collège
(Orateurs: Mme Evelyne Huytebroeck, MM. Jacques De Coster, Denis Grimberghs, André Drouart et Hervé Hasquin, Président du Collège)
de M. Michel Lemaire (organisation de la politique du tourisme) à M. Didier Gosuin, membre du Collège
(Orateurs: M. Michel Lemaire, Mme Isabelle Molenberg, MM. Mery Hermanus, Philippe Smits, Didier van Eyll et Didier Gosuin, membre du Collège)

## Question d'actualité

de M. Paul Galand (fermeture du home «Acacias Louise») et réponse de M. Charles Picqué, membre du Collège.19

## Interpellation

de M. André Drouart (conséquences de l'application des décrets du 5 août 1995 de la Communauté française sur l'organisation des établissements d'enseignement secondaire et supérieur de la CCF) à M. Eric Tomas, membre du Collège
(Orateurs: MM. André Drouart et Eric Tomas, membre du Collège)

## Questions orales

de Mme Marie Nagy (compétences législatives de la CCF) et réponse de M. Hervé Hasquin, Président du Collège.22
de M. André Drouart (situation de l'IMP de l'Institut A. Herlin) . ..... 23
de M. André Drouart (refus d'inscription de jeunes au sein des établissements scolaires) et réponses de M. Eric Tomas, membre du Collège ..... 24
Commissions ..... 24
Communication ..... 24
Annexes ..... 26