---
source_file: example_latex.pdf
page_number: 4
total_pages: 32
total_images: 0
document_title: The 18.821 Mathematics Project Lab Report
language: en
document_type: report
---

MIT OpenCourseWare
http://ocw.mit.edu

# 18.821 Project Laboratory in Mathematics 

Spring 2013

For information about citing these materials or our Terms of Use, visit: http://ocw.mit.edu/terms.