---
source_file: example_latex.pdf
page_number: 2
total_pages: 32
total_images: 1
document_title: The 18.821 Mathematics Project Lab Report
language: en
document_type: report
images:
- id: img-0.jpeg
  filename: page2_img1.jpg
  image_type: graph
  title: Champ de vecteurs et trajectoires
  description: Graphique montrant un champ de vecteurs avec des trajectoires superposées.
  detailed_description: Ce graphique représente un champ de vecteurs défini par les
    équations x' = -2x + 5y et y' = -2x + 4y. Les flèches indiquent la direction et
    la magnitude du champ de vecteurs à différents points du plan. Les courbes superposées
    représentent les trajectoires des points dans ce champ de vecteurs, illustrant
    comment les points se déplacent au fil du temps.
---

![[graph] - Champ de vecteurs et trajectoires](images/page2_img1.jpg)

Figure 1. My first .pdf figure.
If you want a number for an equation, do it like this:

$$
\lim _{n \rightarrow \infty} \sum_{k=1}^{n} \frac{1}{k^{2}}=\frac{\pi}{6}
$$

This can then be referred to as (1), which is much easier than keeping track of numbers by hand. To group several equations, aligning on the $=$ sign, do it like this:

$$
\begin{aligned}
x_{1}+2 x_{2}+3 x_{3} & =7 \\
y & =m x+c \\
& =4 x-9
\end{aligned}
$$

You can easily embed hyperlinks into the output .pdf document: click here for example.

# 3. Images 

Figure 1 is an example of a .pdf image put into a floating environment, which means LaTeX will draw it wherever there's enough space left in your manuscript. Look at the .tex original to see how to insert a figure like this.

## 4. TheORems AND SUCH

An example of a "conjecture environment" is given below, in Conjecture 4.1. Theorems, lemmas, propositions, definitions, and such all use the same command with the appropriate name changed. In fact,