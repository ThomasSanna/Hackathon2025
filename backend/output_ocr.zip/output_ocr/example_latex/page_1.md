---
source_file: example_latex.pdf
page_number: 1
total_pages: 32
total_images: 0
document_title: The 18.821 Mathematics Project Lab Report
language: en
document_type: report
summary: This document is a LaTeX template for the 18.821 Mathematics Project Lab
  Report. It provides examples of using LaTeX for mathematical symbols, equations,
  images, and theorems. The document also includes instructions on how to use LaTeX
  for creating reports, citing sources, and handling file types. It emphasizes the
  importance of citing sources to avoid plagiarism and provides examples of how to
  reference literature and websites.
key_points:
- LaTeX template for 18.821 Mathematics Project Lab Report
- Examples of mathematical symbols and equations
- Instructions for using LaTeX for reports
- Guidelines for citing sources and avoiding plagiarism
- Handling file types and converting between formats
authors:
- X. Burps
- P. Gurps
date: February 10, 2013
organizations:
- MIT OpenCourseWare
---

# THE 18.821 MATHEMATICS PROJECT LAB REPORT [REPLACE THIS WITH YOUR OWN SHORT DESCRIPTIVE TITLE!] 

X. BURPS, P. GURPS

Abstract. This is a $\mathrm{IT}_{\mathrm{E}} \mathrm{X}$ template for 18.821 , which you can use for your own reports.

## 1. INTRODUCTION

This brief document shows some examples of the use of $\mathrm{IT}_{\mathrm{E}} \mathrm{X}$ and indicates some special features of the Math Lab report style. The course website contains links to several $\mathrm{LT}_{\mathrm{E}} \mathrm{X}$ manuals.

End the introduction by describing the contents of the paper section by section, and which team member(s) wrote each of them. For instance, Section 6 discusses referencing, and is written by P. Gurps.

## 2. $\mathrm{LT}_{\mathrm{E}} \mathrm{X}$ Examples

Here are some ways of producing mathematical symbols. Some are pre-defined either in $\mathrm{LT}_{\mathrm{E}} \mathrm{X}$ or in the AMS package which this document loads. For instance, sums and integrals, $\sum_{i=1}^{n} 1=n, \int_{0}^{n} x d x=n^{2} / 2$. We've defined a few other symbols at the start of the document, for instance $\mathbb{N}, \mathbb{Q}, \mathbb{Z}, \mathbb{R}$. You can make marginal notes for yourself or your co-authors like this:

If you want to typeset equations, there are many choices, with or without numbering:

$$
\int_{0}^{1} x d x=1 / 2
$$

or

$$
\sum_{i=1}^{\infty} i=-\frac{1}{12}
$$

or

$$
1-1+1-\cdots=\frac{1}{2}
$$

[^0]
[^0]:    Date: February 10, 2013.