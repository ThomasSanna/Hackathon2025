---
source_file: example_latex.pdf
page_number: 3
total_pages: 32
total_images: 0
document_title: The 18.821 Mathematics Project Lab Report
language: en
document_type: report
---

if you look at the top of this .tex file, you can see where we've defined these environments.

Conjecture 4.1 (Vaught's Conjecture). Let $T$ be a countable complete theory. If $T$ has fewer than $2^{\aleph_{0}}$ many countable models (up to isomorphism), then it has countably many countable models.
Theorem 4.2. When it rains it pours.
Proof. Well, yes.

# 5. Filetypes used by LaTeX 

You will write your text as a .tex file using any text editor (though WYSIWYG editors are troublesome). Traditionally one then runs LaTeX and obtains a .dvi file, which can be viewed on the screen using a dvi viewer. To include images, and then prepare the file for printing or submission, one typically translates the .dvi into either .ps (Postscript) or .pdf (Adobe PDF).

Your report will be submitted as a .pdf document. The pdflatex command produces a .pdf file directly from a .tex file. This command works well with included .pdf files, but does not handle .eps files.
An .eps file can be converted to a .pdf file by viewing it and saving as a .pdf file, or by ps2pdf filename.eps, which produces filename.pdf. Under MikTeX with WinEdt, all necessary commands will appear under "Accessories" in the WinEdt menu.

Finally, Matlab can be made to produce .eps files by typing
print -deps filename
at the prompt.

## 6. Quoting SOURCES

In your work, keep notes of the literature you've used, including websites. Cite the references you use; failure to do so constitutes plagiarism. Every bibliography item should be referenced somewhere in the paper. Quote as precisely as possible: [1, pages 76-78] rather than [1]. [2] was a useful background reference, too.

## REFERENCES

[1] Gurps, P., Care and feeding of maths professors. Cambridge Univ. Press, 2008.
[2] Burps, X. Terrors and errors of project lab. Journal of Wildlife and Conservation 21 (2008), 112-134.

## APPENDIX

Appendices are useful for putting in code or data.