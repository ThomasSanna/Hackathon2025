---
source_file: cadastraux_paris_09_54.pdf
page_number: 1
total_pages: 8
total_images: 1
document_title: Plans cadastraux de Paris 1809-1854
language: fr
document_type: Répertoire numérique détaillé
summary: Le document présente un répertoire numérique détaillé des plans cadastraux
  de Paris, couvrant la période de 1809 à 1854. Il inclut des informations sur les
  auteurs, les dates, et les organisations impliquées. Le répertoire est basé sur
  le Catalogue général des cartes, plans et dessins d'architecture, et a été rédigé
  par Aurélie Peylhard de la Mission Cartes et Plans. Les plans sont conservés aux
  Archives nationales de France à Pierrefitte-sur-Seine.
key_points:
- Plans cadastraux de Paris couvrant la période de 1809 à 1854.
- Répertoire numérique détaillé basé sur le Catalogue général des cartes, plans et
  dessins d'architecture.
- Rédigé par Aurélie Peylhard de la Mission Cartes et Plans.
- Conservé aux Archives nationales de France à Pierrefitte-sur-Seine.
- Inclut des informations sur les auteurs, les dates, et les organisations impliquées.
authors:
- Aurélie Peylhard
date: '2021'
organizations:
- Archives nationales (France)
- Mission Cartes et Plans
images:
- id: img-0.jpeg
  filename: page1_img1.jpg
  image_type: logo
  title: Archives Nationales
  description: Logo des Archives Nationales
  detailed_description: Le logo des Archives Nationales est composé des mots 'Archives
    Nationales' avec un style de police distinctif. Les lettres sont de différentes
    couleurs, principalement en bleu et en or, et sont disposées de manière à former
    un design cohésif et reconnaissable.
---

# ![[logo] - Archives Nationales](images/page1_img1.jpg) 

## Plans cadastraux de Paris 1809-1854 (CP/F/31/3 à CP/F/31/72)

Répertoire numérique détaillé : documents issus de la sous-série F/31

Aurélie Peylhard, Mission Cartes et Plans

Première édition électronique
Archives nationales (France)
Pierrefitte-sur-Seine
2021