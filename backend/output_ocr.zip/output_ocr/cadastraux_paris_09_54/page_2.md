---
source_file: cadastraux_paris_09_54.pdf
page_number: 2
total_pages: 8
total_images: 0
document_title: Plans cadastraux de Paris 1809-1854
language: fr
document_type: Répertoire numérique détaillé
---

https://www.siv.archives-nationales.culture.gouv.fr/siv/IR/FRAN_IR_059652
Cet instrument de recherche a été rédigé dans le système d'information archivistique des Archives nationales.

Ce document est écrit en français.
Conforme à la norme ISAD(G) et aux règles d'application de la DTD EAD (version 2002) aux Archives nationales.