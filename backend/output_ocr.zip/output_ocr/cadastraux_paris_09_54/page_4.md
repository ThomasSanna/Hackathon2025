---
source_file: cadastraux_paris_09_54.pdf
page_number: 4
total_pages: 8
total_images: 0
document_title: Plans cadastraux de Paris 1809-1854
language: fr
document_type: Répertoire numérique détaillé
---

# Sommaire 

Plans cadastraux de Paris (feuilles d'immeubles) ..... 5
Inventaire et numérisations des cotes CP/F/31/3 à CP/F/31/14 ..... 9
Inventaire et numérisations des cotes CP/F/31/15 à CP/F/31/20 ..... 9
Inventaire et numérisations des cotes CP/F/31/21 à CP/F/31/25 ..... 9
Inventaire et numérisations des cotes CP/F/31/26 à CP/F/31/30/BIS ..... 9
Inventaire et numérisations des cotes CP/F/31/31 à CP/F/31/35 ..... 9
Inventaire et numérisations des cotes CP/F/31/36 à 40 ..... 9
Inventaire et numérisations des cotes CP/F/31/41 à 45 ..... 9
Inventaire et numérisations des cotes CP/F/31/46 à 50 ..... 9
Inventaire et microfilms des cotes CP/F/31/51 à CP/F/31/72 ..... 9