# Carte Mentale - Répertoire numérique détaillé des plans cadastraux de Paris (1809-1854)

```mermaid
mindmap
  root((Répertoire numérique détaillé des plans cadastraux de Paris (1809-1854)))
    Contexte historique et urbain
      Période couverte
        1809 à 1854 : Transformation de Paris au XIXe siècle
      Importance pour l'histoire urbaine
        Développement de l'urbanisme parisien
        Impact sur la fiscalité et l'aménagement
      Évolution des techniques
        Méthodes de cadastre
        Outils de cartographie
    Gestion et conservation des documents
      Institutions impliquées
        Archives nationales [Pierrefitte-sur-Seine]
        Mission Cartes et Plans
      Types de documents
        Plans cadastraux
        Répertoire numérique détaillé
        Catalogue général des cartes, plans et dessins d'architecture
      Méthodes de conservation
        Numérisation et archivage électronique
        Classement dans la sous-série F/31
    Méthodologie archivistique
      Rédaction du répertoire
        Auteur : Aurélie Peylhard
        Base : Catalogue général des cartes et plans
      Structure du répertoire
        Informations sur les auteurs
        Dates et organisations impliquées
        Références aux cotes [CP/F/31/3 à CP/F/31/72]
      Édition et diffusion
        Première édition électronique [2021]
        Accessibilité en ligne
    Rôle des institutions publiques
      Préservation du patrimoine
        Protection des documents historiques
        Valorisation des archives cartographiques
      Collaboration institutionnelle
        Rôle de la Mission Cartes et Plans
        Partenariats avec les Archives nationales
      Cadre légal et réglementaire
        Lois sur la conservation des archives
        Normes de numérisation et d'archivage
    Évolution des techniques de cadastre et fiscalité
      Techniques de cadastre
        Méthodes de relevé foncier
        Outils de mesure et de représentation
      Impact sur la fiscalité
        Base pour l'imposition foncière
        Modernisation des systèmes fiscaux
      Innovations cartographiques
        Précision et détails des plans
        Utilisation des plans pour l'aménagement urbain
```
