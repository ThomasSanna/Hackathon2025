---
source_file: cadastraux_paris_09_54.pdf
page_number: 3
total_pages: 8
total_images: 0
document_title: Plans cadastraux de Paris 1809-1854
language: fr
document_type: Répertoire numérique détaillé
---

# Préface 

Le présent inventaire s'appuie sur le Catalogue général des cartes, plans et dessins d'architecture. Répertoire des plans cadastraux de Paris, cotés F31 3 à 72, levés de 1809 à 1854 , par Michel Le Moël en 1969 (771 p.)