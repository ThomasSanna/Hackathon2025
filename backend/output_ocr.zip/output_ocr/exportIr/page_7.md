---
source_file: exportIr.pdf
page_number: 7
total_pages: 8
total_images: 0
document_title: 'Intérieur ; Direction générale de Sûreté nationale. Fichier central
  de la Sûreté nationale : dossiers individuels (fin XIXe-1940)'
language: fr
document_type: Répertoire alphabétique des dossiers conservés dans les versements
  19940432 à 19940492
---

# Répertoire alphabétique des dossiers conservés dans les versements 19940432 à 19940492 

19940432/1-19940432/290,19940433/1-19940433/6
Lettre A (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de AAC à ALI
Inventaire nominatif des dossiers individuels de ALK à AZ
Inventaire nominatif des dossiers individuels en A (supplément)

19940434/1-19940434/704,19940435/1-19940435/15,19940436/1-19940436/2
Lettre B (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de BA à BAR
Inventaire nominatif des dossiers individuels de BAS à BEO
Inventaire nominatif des dossiers individuels de BEP à BN
Inventaire nominatif des dossiers individuels de BO à BOZ
Inventaire nominatif des dossiers individuels de BRA à BZ
Inventaire nominatif des dossiers individuels en B (supplément )

19940437/1-19940437/411,19940438/1-19940438/12,19940439/1
Lettre C (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de CAA à CAU
Inventaire nominatif des dossiers individuels de CAV à COL
Inventaire nominatif des dossiers individuels de COM à CZ
Inventaire nominatif des dossiers individuels en C (1er supplément)
Inventaire nominatif des dossiers individuels en C (2e supplément)

19940440/1-19940440/405,19940441/1-19940441/14,19940442/1-19940442/5
Lettre D (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de DA à DEQ
Inventaire nominatif des dossiers individuels de DER à DZ
Inventaire nominatif des dossiers individuels en D (suppléments)

19940443/1-19940443/91,19940444/1
Lettre E (indexé)

1880-1940
Inventaire nominatif des dossiers individuels en E

19940445/1-19940445/298,19940446/1-19940446/9,19940447/1-19940447/5
Lettre F (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de FA à FIH
Inventaire nominatif des dossiers individuels de FIH à FZ
Inventaire nominatif des dossiers individuels de FA à FZ (supplément)