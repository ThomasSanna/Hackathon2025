---
source_file: exportIr.pdf
page_number: 2
total_pages: 8
total_images: 0
document_title: 'Intérieur ; Direction générale de Sûreté nationale. Fichier central
  de la Sûreté nationale : dossiers individuels (fin XIXe-1940)'
language: fr
document_type: Répertoire alphabétique des dossiers conservés dans les versements
  19940432 à 19940492
---

https://www.siv.archives-nationales.culture.gouv.fr/siv/IR/FRAN_IR_050044
Cet instrument de recherche a été rédigé dans le système d'information archivistique des Archives nationales.

Ce document est écrit en français.
Conforme à la norme ISAD(G) et aux règles d'application de la DTD EAD (version 2002) aux Archives nationales.