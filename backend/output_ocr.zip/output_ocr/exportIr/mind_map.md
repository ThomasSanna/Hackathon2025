# Carte Mentale - Répertoire alphabétique des dossiers individuels du Fichier central de la Sûreté nationale (fin XIXe-1940)

```mermaid
mindmap
  root((Répertoire alphabétique des dossiers individuels du Fichier central de la Sûreté nationale (fin XIXe-1940)))
    Contexte historique et administratif
      Période couverte
        Fin du XIXe siècle à 1940
      Institution responsable
        Direction générale de la Sûreté nationale
      Origine des archives
        Conservation initiale à Moscou
        Retour et numérisation en France
    Description et contenu du répertoire
      Type de document
        Répertoire alphabétique des dossiers individuels
      Informations contenues
        Nom et prénom
        Date du dossier
      Volume des données
        Plus de 600 000 dossiers individuels
    Normes et méthodologies archivistiques
      Normes appliquées
        ISAD[G] - Norme internationale de description archivistique
        DTD EAD [Encoded Archival Description], version 2002
      Méthodologies de description
        Dépouillement nominatif des registres
        Collaboration avec Geneanet [2020]
      Standardisation
        Utilisation de microfilms
        Numérisation et accessibilité en ligne
    Acteurs et collaborations
      Institutions publiques
        Archives nationales [France]
        Direction générale de la Sûreté nationale
      Partenariats privés
        Geneanet [pour le dépouillement nominatif]
      Auteurs et contributeurs
        Emilie Charrier, chargée d'études documentaires
    Accessibilité et diffusion
      Support initial
        Microfilms consultables sur place
      Numérisation
        Recherche à distance possible
      Mise à jour et indexation
        Lettres indexées régulièrement mises à jour
        Liens vers inventaires nominatifs
```
