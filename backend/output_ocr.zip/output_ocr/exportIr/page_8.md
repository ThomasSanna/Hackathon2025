---
source_file: exportIr.pdf
page_number: 8
total_pages: 8
total_images: 0
document_title: 'Intérieur ; Direction générale de Sûreté nationale. Fichier central
  de la Sûreté nationale : dossiers individuels (fin XIXe-1940)'
language: fr
document_type: Répertoire alphabétique des dossiers conservés dans les versements
  19940432 à 19940492
---

19940448/1-19940448/509,19940449/1-19940449/8,19940450/1-19940450/4
Lettre G (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de GA à GIE
Inventaire nominatif des dossiers individuels de GIF à GOU
Inventaire nominatif des dossiers individuels de GOU à GZ
Inventaire nominatif des dossiers individuels de GA à GU (supplément)

19940451/1-19940451/255,19940452/1-19940452/6
Lettre H (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de HA à HE
Inventaire nominatif des dossiers individuels de HI à HZ
Inventaire nominatif des dossiers individuels en H (supplément )

19940453/1-19940453/22,19940454/1
Lettre I (indexé)

1880-1940
Inventaire nominatif des dossiers individuels en I
Inventaire nominatif des dossiers individuels en I (supplément)

19940455/1-19940455/117,19940456/1-19940456/2
Lettre J (indexé)

1880-1940
Inventaire nominatif des dossiers individuels en J
Inventaire nominatif des dossiers individuels en J (supplément)

19940457/1-19940457/415,19940458/1-19940458/6
Lettre K (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de KA à KJ
Inventaire nominatif des dossiers individuels de KL à KZ
Inventaire nominatif des dossiers individuels en K (supplément)

19940459/1-19940459/415,19940460/1-19940460/5,19940461/1
Lettre L (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de LA à LEF
Inventaire nominatif des dossiers individuels de LEF à LEX
Inventaire nominatif des dossiers individuels de LEY à LZ
Inventaire nominatif des dossiers individuels de LA à LU (supplément)

19940462/1-19940462/591,19940463/1-19940463/16
Lettre M (indexé)

1880-1940
Inventaire nominatif des dossiers individuels de MA à MAR
Inventaire nominatif des dossiers individuels de MAR à MEL