---
source_file: exportIr.pdf
page_number: 1
total_pages: 8
total_images: 1
document_title: 'Intérieur ; Direction générale de Sûreté nationale. Fichier central
  de la Sûreté nationale : dossiers individuels (fin XIXe-1940)'
language: fr
document_type: Répertoire alphabétique des dossiers conservés dans les versements
  19940432 à 19940492
summary: 'Ce document est un répertoire alphabétique des dossiers individuels conservés
  dans les versements 19940432 à 19940492 de la Direction générale de Sûreté nationale.
  Il couvre la période de la fin du XIXe siècle à 1940 et a été rédigé par Emilie
  Charrier, chargée d''études documentaires. Le document est une édition électronique
  des Archives nationales de France, située à Pierrefitte-sur-Seine. Il est conforme
  à la norme ISAD(G) et aux règles d''application de la DTD EAD (version 2002) aux
  Archives nationales. Le répertoire permet l''accès aux répertoires alphabétiques
  inventoriant les millions de dossiers composant le Fichier central de la Sûreté
  nationale en 1940. Les répertoires ont été établis par les archivistes russes lorsque
  le fonds était conservé à Moscou et étaient consultables sur microfilms. La numérisation
  des microfilms permet désormais la recherche à distance parmi les plus de 600 000
  dossiers individuels. Les répertoires comportent les renseignements suivants : nom
  et prénom, date du dossier. En 2020, un dépouillement nominatif des registres est
  engagé en partenariat avec Geneanet, afin de permettre les recherches nominatives.
  Les lettres indexées sont indiquées dans l''inventaire ci-contre et mises à jour
  régulièrement, avec des liens vers les inventaires nominatifs.'
key_points:
- Le document est un répertoire alphabétique des dossiers individuels de la Direction
  générale de Sûreté nationale.
- Il couvre la période de la fin du XIXe siècle à 1940.
- Le répertoire a été rédigé par Emilie Charrier, chargée d'études documentaires.
- Il est conforme à la norme ISAD(G) et aux règles d'application de la DTD EAD (version
  2002) aux Archives nationales.
- 'Les répertoires comportent les renseignements suivants : nom et prénom, date du
  dossier.'
- Un dépouillement nominatif des registres est engagé en partenariat avec Geneanet
  en 2020.
authors:
- Emilie Charrier
date: '2014'
organizations:
- Archives nationales (France)
- Direction générale de Sûreté nationale
- Geneanet
images:
- id: img-0.jpeg
  filename: page1_img1.jpg
  image_type: logo
  title: Archives Nationales
  description: Logo des Archives Nationales
  detailed_description: Le logo des Archives Nationales est composé des mots 'Archives
    Nationales' avec des couleurs distinctes pour chaque lettre. Les lettres 'A' et
    'N' sont en doré, tandis que les autres lettres sont en bleu.
---

# ![[logo] - Archives Nationales](images/page1_img1.jpg) 

## Intérieur ; Direction générale de Sûreté nationale. Fichier central de la Sûreté nationale : dossiers individuels (fin XIXe-1940)

Répertoire alphabétique des dossiers conservés dans les versements 19940432
à 19940492

Par Emilie Charrier, chargée d'études documentaires

Première édition électronique
Archives nationales (France)
Pierrefitte-sur-Seine
2014