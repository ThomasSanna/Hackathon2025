---
source_file: i1985_1986_0096_02.pdf
page_number: 7
total_pages: 8
total_images: 0
document_title: Rapport Général
language: fr
document_type: rapport
---

(En millions de francs.)

| Nature de la modification |  | Crédits de paiement en + | Crédits de paiement en - |
| :--: | :--: | :--: | :--: |
| Report |  | 41,17 |  |
| Education nationale - Titre IV : <br> - Subventions aux associations sportives, scolaires et universitaires |  | 6,9 |  |
| Environnement - Titre III : <br> - Amélioration de la gestion des réserves naturelles <br> - Revalorisation des moyens de fonctionnement des parcs nationaux | $\begin{gathered} 0,7 \\ 1 \end{gathered}$ | 1,7 |  |
| Environnement - Titre IV : <br> - Majoration de la subvention des moyens de fonctionnement des parcs naturels régionaux et des associations subventionnées |  | 0,5 |  |
| Intérieur et décentralisation - Titre III : <br> - Modernisation de l'orphelinat de la police | 1 |  |  |
| - Sécurité des vols aériens | 0,5 |  |  |
| - Amélioration des moyens informatiques des préfectures | 7 | 9,5 |  |
| - Informatisation du fichier national des substances dangereuses | 1 |  |  |
| Intérieur et décentralisation - Titre IV : <br> - Création de cellules départementales d'interventions chimiques et assurer une meilleure coordination dans la lutte contre les incendies de forêt |  | 11 |  |
| Jeunesse et sports - Titre IV : <br> - Augmentation de la contribution de l'Etat et création de 11 postes F.O.N.J.E.P. | 1,19 |  |  |
| - Promotion des activités de loisirs éducatifs | 6 |  |  |
| - Aide aux centres de vacances | 1,5 |  |  |
| - Formation des animateurs | 1 | 16,09 |  |
| - Augmentation de la contribution de l'Etat et créations de 27 postes F.O.N.J.E.P. | 2,9 |  |  |
| - Promotion des activités du temps libre | 3,5 |  |  |
| Justice - Titre III : <br> - Majoration des crédits des services de l'éducation surveillée, frais de déplacement | 0,5 | 2 |  |
| - et parc automobile | 1,5 |  |  |
| Plan et aménagement du territoire - Titre IV : <br> - Revalorisation de la subvention à l'Institut de recherches économiques et sociales et au centre d'études prospectives d'économie mathématique appliquée à la planification |  | 1,6 |  |
| Redéploiement industriel - Titre IV : <br> - Majoration de la subvention à différents organismes concourant au développement de la politique industrielle |  | 0,3 |  |
| A reporter |  | 90,76 |  |