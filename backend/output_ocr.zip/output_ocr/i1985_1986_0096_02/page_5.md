---
source_file: i1985_1986_0096_02.pdf
page_number: 5
total_pages: 8
total_images: 0
document_title: Rapport Général
language: fr
document_type: rapport
---

# I. - LES MODIFICATIONS APPORTÉES AU MONTANT DES RESSOURCES 

Les répercussions financières des amendements présentés par le Gouvernement sont récapitulés dans le tableau ci-après :
(En millions de francs.)

| Nature de la modification | Crédits de palement en + | Crédits de palement en - |
| :--: | :--: | :--: |
| PREMIERE DELIBERATION |  |  |
| BUDGET GÉNÉral |  |  |
| A. - RECETTES FISCALES |  |  |
| 1. Produit des impôts directs et taxes assimilées : <br> - Impôt sur le revenu |  | 33 |
| - Taxe sur les salaires |  | 50 |
| 2. Produit de l'enregistrement : <br> - Autres conventions et actes civils | 60 |  |
| - Taxe de publicité foncière | 5 |  |
| 3. Produit du timbre et de l'impôt sur les opérations de bourse : <br> - Timbre unique | 116 |  |
| - Actes et écrits assujettis au timbre de dimension | 66 |  |
| - Contrats de transports | 57 |  |
| 6. Produit des contributions indirectes : <br> - Droits de fabrication sur les alcools | 6 |  |
| Total | 310 | 83 |
|  | 227 |  |

Ces diverses modifications se traduisent par une augmentation du montant des ressources de 227 millions de francs.