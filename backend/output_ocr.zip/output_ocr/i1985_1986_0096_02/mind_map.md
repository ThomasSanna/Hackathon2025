# Carte Mentale - Analyse du projet de loi de finances pour 1986 : Rapport général de la commission des Finances du Sénat

```mermaid
mindmap
  root((Analyse du projet de loi de finances pour 1986 : Rapport général de la commission des Finances du Sénat))
    Contexte et acteurs
      Présentation du rapport
        Auteur : M. Maurice Blin, rapporteur général
        Date : 21 novembre 1985
      Organisations impliquées
        Sénat
        Assemblée nationale
        Commission des Finances, du Contrôle budgétaire et des Comptes économiques de la Nation
      Composition de la commission des Finances
        Président : Edouard Bonnefous
        Vice-présidents : Jean Cluzel, Tony Larue, etc.
        Secrétaires : Modeste Legouez, Yves Durand, etc.
    Processus législatif
      Adoption par l'Assemblée nationale
        Projet de loi de finances pour 1986 [n°2951]
        Modifications apportées avant transmission au Sénat
      Examen par le Sénat
        Première session ordinaire de 1985-1986
        Annexe au procès-verbal du 21 novembre 1985
      Échanges entre l'Assemblée nationale et le Sénat
        Références aux documents parlementaires [n°95 pour le Sénat]
        Coordination sur les modifications et l'équilibre financier
    Contenu du projet de loi de finances
      Conditions générales de l'équilibre financier
        Première partie de la loi de finances
        Objectif : Équilibre des ressources et des charges
      Modifications clés
        Ajustement du montant des ressources
        Révision du plafond des charges
      Examen des articles
        Analyse détaillée des articles de la loi
        Impact sur l'équilibre financier global
    Concepts clés et enjeux
      Loi de finances
        Définition et portée juridique
        Rôle dans la gestion des finances publiques
      Équilibre financier
        Importance pour la stabilité économique
        Mécanismes de contrôle et ajustements
      Ressources et charges de l'État
        Sources des ressources [impôts, emprunts, etc.]
        Plafond des charges et gestion des dépenses
```
