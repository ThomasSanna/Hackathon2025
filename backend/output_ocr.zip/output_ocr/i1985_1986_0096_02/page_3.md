---
source_file: i1985_1986_0096_02.pdf
page_number: 3
total_pages: 8
total_images: 0
document_title: Rapport Général
language: fr
document_type: rapport
---

d) Mesures sectorielles et mesures diverses.
Art. 11. - Reconduction de mesures temporaires ..... 56
Art. 12. - Mesures diverses en faveur de la presse ..... 61
Art. 13. - Aménagement du régime de taxe sur la valeur ajoutée en faveur du secteur ..... 66
culturel
Art. 13 bis (nouveau). - Relèvement du seuil d'exigibilité de la taxe sur les salaires due par les associations ..... 69
Article additionnel avant l'article 14 : Impôt sur les grandes fortunes. - Immeubles classés monuments historiques et parcs et jardins y atténant ..... 71
Art. 14. - Impôt sur les grandes fortunes. - Actualisation des seuils. - Majoration conjoncturelle ..... 73
Art. 14 bis (nouveau). - Relèvement de divers tarifs de droits indirects ou de timbre. ..... 75
Art. 15. - Détaxation des carburants agricoles ..... 79
Art. 16. - Tarif de la taxe intérieure de consommation sur les produits pétroliers ..... 80
Art. 17. - Tarif de la taxe intérieure de consommation des produits pétroliers. - Institution d'une nouvelle ligne ..... 84
Art. 18. - Abrogation de l'ordonnance du 18 mai 1983 relative à la majoration de la taxe intérieure de consommation sur les produits pétroliers ..... 88
Art. 18 bis (nouveau). - Actualisation de l'assiette des versements dus par les entre- prises au titre du $0,2 \%$ formation continue ..... 89
II. - RESSOURCES AFFECTEES
Art. 19. - Dispositions relatives aux affectations ..... 91
Art. 20. - Taxe sur les huiles perçue au profit du budget annexe des prestations sociales agricoles ..... 92
Art. 21. - Aménagement de la taxe et prélèvement sur certaines recettes perçues par les sociétés diffusant des programmes de télévision ..... 94
Art. 22. - Aménagement des recettes du compte d'affectation spéciale. - Fonds national pour le développement du sport ..... 99
Art. 23. - Fixation du taux du prélèvement sur les recettes de l'Etat au titre de la dotation globale de fonctionnement ..... 101
TITRE II
DISPOSITIONS RELATIVES AUX CHARGES
Art. 24. - Confirmation de dispositions législatives antérieures ..... 103
Art. 25. - Majoration des rentes viagères ..... 104
TITRE III
DISPOSITIONS RELATIVES A L'ÉQUILIBRE DES RESSOURCES ET DES CHARGES
Art. 26. - Equilibre général du budget ..... 111