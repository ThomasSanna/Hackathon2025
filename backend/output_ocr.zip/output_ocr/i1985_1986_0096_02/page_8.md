---
source_file: i1985_1986_0096_02.pdf
page_number: 8
total_pages: 8
total_images: 0
document_title: Rapport Général
language: fr
document_type: rapport
---

| Nature de la modification |  | Crédits de paiement en + | Crédits de paiement en - |
| :--: | :--: | :--: | :--: |
| Report |  | 90,76 |  |
| Relations extérieures. <br> 1. - Services diplomatiques et généraux - Titre IV : <br> - Majoration de subventions versées à divers orga- <br> nismes |  | 0,8 |  |
| Santé et solidarité nationale - Titre IV : <br> Majoration des crédits destinés à financer : <br> - La prévention sanitaire | 3 |  |  |
|  |  |  |  |
|  | - Les structures associatives | 8 |  |
|  | - Les centres sociaux | 2 |  |
|  | - Les services d'accueil des jeunes enfants et informa- <br> tion des familles | 7 | 33,26 |
|  | - Les services de soins à domicile des personnes âgées . | 3 |  |
|  | - Diverses mesures en faveur des handicapés | 8 |  |
|  | - Création de 21 emplois F.O.N.J.E.P. | 2,26 |  |
| Services du Premier ministre. <br> I. - Services généraux - Titre III : <br> Majoration des crédits pour : <br> - Le Conseil national de la communication audiovisuelle |  |  |  |
|  | 0,5 |  |  |
|  | - La réalisation d'études sur les aides à la presse .... | 0,5 |  |
|  | - La scolarité des stagiaires de l'Institut national d'admi- <br> nistration publique | 1 | 2,6 |
|  | - Les dépenses de fonctionnement de la Haute Autorité de la communication audiovisuelle | 0,6 |  |
|  | I. - Services généraux - Titre IV : <br> - Centre national d'information sur les droits de la femme | 2 |  |
|  | - Diverses actions | 6,5 | 13,6 |
|  | - Subventions à divers organismes | 5,1 |  |
| Travail, emploi et formation professionnelle - Titre III : <br> - Renforcement des moyens d'études du C.E.R.E.O. .. |  |  |  |
| Travail, emploi et formation professionnelle - Titre IV : <br> - Soutien de l'Etat à diverses actions de formation .... |  | 6 |  |
|  | - Développement des moyens informatiques du C.E.S.I. <br> - Création d'un centre de formation professionnelle des adultes | 1 | 23 |
|  | - Encouragement à la formation ouvrière | 15 |  |
| Urbanisme, logement et transports - Titre III : <br> - Accroissement des moyens de la météorologie nationale |  |  | 2 |
| A reporter |  |  | 166,52 |