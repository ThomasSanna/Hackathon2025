---
source_file: i1985_1986_0096_02.pdf
page_number: 2
total_pages: 8
total_images: 0
document_title: Rapport Général
language: fr
document_type: rapport
---

# SOMMAIRE 

Pages
INTRODUCTION ..... 3
I. - LES MODIFICATIONS APPORTEES AU MONTANT DES RESSOURCES ..... 4
II. - LES MODIFICATIONS APPORTEES AU PLAFOND DES CHARGES ..... 5
EXAMEN DES ARTICLES ..... 11
TITRE PREMIER
DISPOSITIONS RELATIVES AUX RESSOURCES
I. - IMPOTS ET REVENUS AUTORISÉS
A. - DISPOSITIONS ANTERIEURES
Article premier. - Autorisation de percevoir les impôts existants ..... 11
B. - MESURES FISCALES
a) Impôt sur le revenu
Art. 2. - Barème de l'impôt sur le revenu et mesures d'accompagnement ..... 13
b) Mesures relatives aux entreprises.
Art. 3. - Réduction du taux de l'impôt sur les sociétés sur les bénéfices non distribués ..... 19
Art. 4. - Assouplissement du régime du report en arrière des pertes ..... 27
Art. 5. - Régime fiscal des sociétés à responsabilité limitée à associé unique et des exploitations agricoles à responsabilité limitée ..... 29
Art. 5 bis (nouveau). - Impôt sur les sociétés : changement de l'objet social ou de l'activité réelle d'une société ..... 39
Art. 6. - Relèvement du plafond d'amortissement des voitures particulières ..... 42
Art. 7. - Reconduction d'un prélèvement sur les entreprises de production pétrolière ..... 43
Art. 8. - Précisions concernant le régime des entreprises nouvelles ..... 45
c) Mesures de simplification et d'actualisation.
Art. 9. - Mesures de simplification d'obligations déclaratives ..... 48
Art. 10. - Mesures de recouvrement ..... 53