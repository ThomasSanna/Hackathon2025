---
source_file: i1985_1986_0096_02.pdf
page_number: 6
total_pages: 8
total_images: 0
document_title: Rapport Général
language: fr
document_type: rapport
---

# II. - LES MODIFICATIONS APPORTÉES AU PLAFOND DES CHARGES 

Le Gouvernement a proposé et l'Assemblée nationale a retenu les dispositions suivantes :
(En millions de francs.)

| Nature de la modification |  | Crédits de palement en + | Crédits de palement en - |
| :--: | :--: | :--: | :--: |
| PREMIERE DELIBERATION |  |  |  |
| A. - DÉPENSES ORDINAIRES DES SERVICES CIVILS |  |  |  |
| Justice - Titre III : <br> - Mise en cuvre en 1988 de la réforme de la procédure d'instruction en matière pénale (création de 50 emplois d'auditeurs en justice, de 25 magistrats et de 25 greffiers) |  | 8,97 |  |
| Economie, finances et budget. |  |  |  |
| II. - Services financiers - Titre III : <br> - Abonder les crédits du chapitre 37-08 jugés insuffisants |  | 10 |  |
| DEUXIEME DELIBERATION |  |  |  |
| A. - DEPENSES ORDINAIRES DES SERVICES CIVILS |  |  |  |
| Agriculture - Titre IV : <br> - Amélioration du cadre de vie | 0,2 |  |  |
| - 4 postes supplémentaires F.O.N.J.E.P. | 0,2 | 7,4 |  |
| - Bourses et ramassage scolaire | 5 |  |  |
| - Valorisation de la production agricole | 2 |  |  |
| Commerce, artisanat et tourisme - Titre IV : <br> - Aide de l'Etat au mouvement associatif | 1,2 | 4,8 |  |
| - Aide à la restructuration des commerces | 3,6 |  |  |
| Culture - Titre IV : <br> - Renforcement de l'aide à l'action culturelle |  | 3 |  |
| Economie, finances et budget - Titre III : <br> - Développement de l'informatisation dans les services extérieurs du Trésor |  | 2,5 |  |
| Education nationale - Titre III : <br> - Provision au bénéfice de la médecine scolaire | 1,5 |  |  |
| - Majoration de la subvention de fonctionnement au Conservatoire national des arts et métiers | 1 | 4,5 |  |
| - et au Muséum national d'histoire naturelle | 1 |  |  |
| - Informatisation des bibliothèques universitaires | 1 |  |  |
| A reporter |  | 41,17 |  |