# Carte Mentale - Compte rendu analytique de la 229ème séance publique du Comité contre la torture : Examen du deuxième rapport périodique du Danemark

```mermaid
mindmap
  root((Examen du deuxième rapport périodique du Danemark par le Comité contre la torture (229ème séance)))
    Contexte et cadre général
      Séance et organisation
        229ème séance publique du Comité contre la torture
        Date et lieu : 14 novembre 1995, Genève
      Acteurs impliqués
        Nations Unies [Comité contre la torture]
        Représentants du Danemark
        Président : M. Dipanda Mouelle
        Experts : M. Reimann et autres
      Documentation
        Deuxième rapport périodique du Danemark
        Compte rendu analytique [CAT/C/SR.229]
    Intégration des instruments internationaux
      Système dualiste du Danemark
        Définition : Intégration des traités internationaux dans le droit interne
        Application de la Convention contre la torture
      Législation nationale
        Adaptation des lois danoises aux normes internationales
        Mesures législatives spécifiques contre la torture
      Convention contre la torture
        Article 19 : Obligation de présenter des rapports
        Définition de la torture et des traitements inhumains
    Législation et réformes
      Réformes législatives
        Renforcement des lois contre la torture
        Adaptation aux recommandations du Comité
      Traitement des plaintes contre la police
        Réformes du système de traitement des plaintes
        Mesures pour garantir l'impartialité
      Définitions et sanctions
        Définition légale de la torture
        Sanctions pour les traitements inhumains ou dégradants
    Mécanismes de protection des droits humains
      Rôle de l'ombudsman
        Fonctions et pouvoirs
        Rôle dans la protection contre la torture
      Procédures judiciaires
        Accès à la justice pour les victimes
        Rôle des tribunaux dans l'application de la Convention
      Surveillance et évaluation
        Suivi des recommandations du Comité
        Évaluation périodique des mesures prises
    Débats et questions clés
      Points discutés lors de la séance
        Application effective de la Convention
        Définitions légales et leur conformité
      Recommandations du Comité
        Amélioration des procédures judiciaires
        Renforcement des mécanismes de plainte
      Prochaines étapes
        Publication des comptes rendus [addendas]
        Calendrier des rectifications et suivis
```
