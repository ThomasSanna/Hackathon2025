---
source_file: 23248.pdf
page_number: 1
total_pages: 8
total_images: 1
document_title: Rapport d'Activité
language: fr
document_type: rapport
summary: Le rapport d'activité de l'ORSTOM (Institut Français de Recherche Scientifique
  pour le Développement en Coopération) pour l'année 1985 présente les efforts de
  renouvellement et de modernisation de l'institut. Il met en lumière les progrès
  réalisés dans divers départements de recherche, notamment en climatologie, en développement,
  et en coopération internationale. Le rapport souligne également les défis et les
  succès de l'institut, y compris l'installation dans de nouveaux locaux, l'obtention
  de crédits nécessaires pour des projets de construction et de modernisation, et
  le renforcement des liens de coopération avec divers pays et institutions. Les activités
  de recherche sont décrites comme étant très productives, avec des résultats fondamentaux
  et appliqués issus de longues années d'efforts continus. Le rapport inclut également
  des discussions sur les stratégies de prévention et de contrôle, les conditions
  de la sécurité alimentaire, et les moyens financiers et humains de l'institut.
key_points:
- Efforts de renouvellement et de modernisation de l'ORSTOM en 1985.
- Installation dans de nouveaux locaux et obtention de crédits pour des projets de
  construction.
- Renforcement des liens de coopération avec divers pays et institutions.
- Activités de recherche très productives avec des résultats fondamentaux et appliqués.
- Discussion sur les stratégies de prévention et de contrôle, les conditions de la
  sécurité alimentaire, et les moyens financiers et humains de l'institut.
authors:
- Pierre LAVAU
- Alain RUELLAN
date: '1985'
organizations:
- ORSTOM
- Institut Français de Recherche Scientifique pour le Développement en Coopération
images:
- id: img-0.jpeg
  filename: page1_img1.jpg
  image_type: logo
  title: Logo avec des cercles
  description: Image d'un logo composé de deux cercles gris sur un fond blanc
  detailed_description: L'image montre un logo simple mais élégant. Il se compose
    de deux cercles gris superposés, créant un effet visuel intéressant. Les cercles
    sont placés de manière à ce qu'ils se chevauchent partiellement, avec un espace
    blanc entre eux. Le fond de l'image est blanc, ce qui permet aux cercles gris
    de ressortir clairement.
---

# RAPPORT D'ACTIVITÉ 

![[logo] - Logo avec des cercles](images/page1_img1.jpg)