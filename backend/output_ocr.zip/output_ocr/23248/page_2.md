---
source_file: 23248.pdf
page_number: 2
total_pages: 8
total_images: 0
document_title: Rapport d'Activité
language: fr
document_type: rapport
---

4
Une Recherche Fondamentale pour l'Action :
Connaissances Climatiques et Développement

11
Les Départements,
Opérateurs de la Recherche

12
Département A :
Climat, Tectonique, Surface

19
Département B :
Evaluation et Contrôle des Repercussions
Induites par les Politiques de Développement

25
Département C :
Necessite d'une Démarche Intégrée

33
Département D :
Confirmation des Options
et Nouvelles Orientations

38
Département E :
Les Conditions de la Sécurité Alimentaire

43
Département F :
Energies, Eau, Matières Premières

47
Département G :
Pour l'Amélioration de la Santé,
Recherches Fomfamentales,
Nouveaux Outils Méthodologiques,
Stratégies de Prévention et de Contrôle

55
Département H :
Quelques Questions Ciels
Relatives an Développement

60
Annexe :
Grands Programmes et Départements

63
DIVA :
Des Outils et des Ouvertures
pour la Recherche

79
Services Scientifiques et Techniques

85
Services des Relations Extérieures :
Une Coopération Internationale en Extension

100
Les Moyens

101
Moyens en Personnels

106
Moyens Financiers