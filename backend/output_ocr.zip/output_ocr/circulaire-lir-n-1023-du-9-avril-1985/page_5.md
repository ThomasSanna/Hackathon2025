---
source_file: circulaire-lir-n-1023-du-9-avril-1985.pdf
page_number: 5
total_pages: 8
total_images: 0
document_title: Circulaire du directeur des contributions L.I.R. No 1023 du 9 avril
  1985
language: fr
document_type: circulaire
---

par l'exploitant diffère de la taxe en aval sur les livraisons et prestacien de l'exploitant. Il en résultera automatiquement un bénéfice ou une perta selon le cas.

Pour la détermination du bénéfice on considérera en effet la ta: en aval comme recette d'exploitation et la taxe en amont effective sorme dépense d'exploitation.

En régime forfaitaire, le taux de la taxe sur la valeur ajoutée à facturer par l'exploitant forestier du fait de la livraison de bois est do $3 \%$ du prix hors taxe. Lorsque l'exploitant forestier ne facture pas séparément la taxe sur la valeur ajoutée, celle-ci est de $2,913 \%$ de la recette brute.

En vertu de l'article 60 L. T.V.A. le producteur forestier a la faculté de renoncer sous certaines conditions à l'imposition forfaitaire prévue à l'art. 58 L. T.V.A. et de soumettre les opérations effectuées dans le cadre de son exploitation forestière au régime normal de la taxo sur la valeur ajoutée.

En régime normal le taux de la taxe sur la valeur ajoutée à facturer par l'exploitant forestier du fait de la livraison de bois est de $6 \%$ du prix hors taxe. Le fonctionnement du compte T.V.A. en régime norral n'appelle pas de commentaire à cet endroit. Rappelons seulement qu'en prizcipe les opérations relatives à la taxe sur la valeur ajoutée n'affectent pas le résultat.

Lorsque le contribuable détermine le bénéfice imposable par comt a raison des recettes et des dépenses d'exploitation, les règles suivantes sont à observer.

Les recettes d'exploitation sont à prendre en considération ave: le montant brut, c'est-à-dire taxe incluse. Les dépenses d'exploitation sont également à aligner avec le montant brut, y compris la taxe.

Le montant de T.V.A. versé à l'administration de l'enregistrement constitue également une dépense d'exploitation.