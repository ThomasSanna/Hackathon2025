---
source_file: circulaire-lir-n-1023-du-9-avril-1985.pdf
page_number: 7
total_pages: 8
total_images: 0
document_title: Circulaire du directeur des contributions L.I.R. No 1023 du 9 avril
  1985
language: fr
document_type: circulaire
---

1. Il doit s'agir d'une exploitation non mise en coupes réglées.
2. L'exploitant ne doit pas être obligé à la tenue d'une comptabilit régulière et ne doit en fait pas tenir de comptabilité pareille.

Le produit brut s'entend du prix global de réalisation du matériel ligneux, abstraction faite de la taxe sur la valeur ajoutée. Vel est le cas indépendamment du régime de taxe sur la valeur ajoutée choisi par l'exploitant, régime normal ou régime forfaitaire.

Le forfait de 35 pour cent couvre les frais de coupe et les frais connexes.

Sont à considérer comme frais de coupe et frais connexes : les frais de coupe proprement đits, les frais de conditionnement (notamment débitage, décorticage), les frais de transport, les frais de vente.

Dans le régime normal de la taxe sur la valeur ajoutée, la taxe facturée par l'exploitant forestier à ses clients et qu'il doit à l'administration de l'enregistrement après compensation éventuelle avec les taxes en amont, n'est pas couverte par le forfait pour frais de coupe et frais connexes. (Dans le régime forfaitaire de T.V.A. l'exploitant n'a pas de taxe à payer parce que la taxe versée par le client à l'exploitant est compensée avec la taxe forfaitaire en amont qui est réputée fixée exactement au montant de la taxe versée par le client).
c) Les frais de boisement et de reboisement suivent un régime spécial établi par l'article 75 L.I.R. Il est rappelé que ce régime spécial vaut inđépendearment du mode de détermination du bénéfice. Le régime sera exposé sub 8 ci dessous.
8. Frais de boisement et de reboisement

Les frais de boisement et de reboisement comprennent les frais préparatoires de nettoyage du sol, les frais de plantation ou de replantation proprement dits et les frais ultérieurs de culture.

En ce qui concerne les essences feuillues, tous ces frais sont déduo. tibles comme dépenses courantes au titre de l'exercice en cours.