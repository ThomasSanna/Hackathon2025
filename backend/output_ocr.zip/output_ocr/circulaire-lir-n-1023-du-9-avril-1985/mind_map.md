# Carte Mentale - Détermination et imposition du bénéfice forestier : Cadre réglementaire et modalités pratiques

```mermaid
mindmap
  root((Cadre réglementaire et fiscal des bénéfices forestiers))
    Définitions et cadre général
      Exploitation forestière
        Définition légale
        Activités incluses [boisement, reboisement, etc.]
      Exercice forestier
        Périodicité et durée
        Alignement sur l'exercice comptable général
      Applicabilité des dispositions fiscales
        Bénéfice commercial
        Exploitations agricoles
    Détermination du bénéfice forestier
      Recettes d'exploitation
        Vente de bois et produits forestiers
        Subventions et aides publiques
        Taxe sur la valeur ajoutée [TVA]
      Dépenses d'exploitation
        Frais de boisement et reboisement
        Dépenses courantes [entretien, gardiennage, etc.]
        Amortissements et provisions
      Valeur comptable du bois sur pied
        Méthodes d'évaluation
        Prix d'acquisition minimum des terrains
        Réévaluation de la valeur comptable
      Produit moyen annuel de la croissance naturelle
        Calcul et imputation
        Impact sur le bénéfice imposable
    Cas particuliers et revenus exceptionnels
      Revenu forestier extraordinaire
        Définition et exemples [tempêtes, incendies]
        Traitement fiscal spécifique
      Cas de force majeure
        Reconnaissance des événements
        Impact sur l'imposition
      Coupes réglées vs non réglées
        Définition des coupes réglées
        Cession d'exploitations : règles spécifiques
    Modalités de cession et réévaluation
      Cession d'une exploitation non mise en coupes réglées
        Règles fiscales applicables
        Évaluation des actifs
      Cession d'une exploitation mise en coupes réglées
        Règles fiscales applicables
        Impact sur la valeur comptable
      Réévaluation de la valeur comptable
        Conditions et modalités
        Effets sur l'imposition
```
