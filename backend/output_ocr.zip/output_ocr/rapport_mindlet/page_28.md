---
source_file: rapport_mindlet.pdf
page_number: 28
total_pages: 32
total_images: 0
---

| Nom | Description | Rendu | Performance | Utilisation | Communauté |
| :--: | :--: | :--: | :--: | :--: | :--: |
| Quasar Framework et Weex | Framework <br> Vue.js pour applications multiplateformes | Rendu hybride / natif | Très performant | Applications avec une base de code unique, intégration Vue.js | Actif, surtout pour Vue.js |
| Ionic Framework | Framework pour applications hybrides, utilise Angular, React ou Vue | WebView | Limité, moins performant que natif | Applications nonintensives en ressources | Large et bien établie |
| jQuery Mobile et PhoneGap | Solutions pour applications simples en HTML/CSS/JS | WebView | Limité, moins performant que natif | Prototypes et applications simples | Moins active aujourd'hui |
| Cordova <br> (Apache <br> Cordova) | Framework pour applications hybrides, utilise des technologies web standards | WebView | Limité, moins performant que natif | Applications simples | Bonne, mais en déclin |
| Capacitor | Projet de l'équipe Ionic, accès aux API natives | WebView, accès natif | Limité, moins performant que natif | Applications avec interaction native | Croissante |
| NativeScript | Framework pour applications natives avec JS, TS en utilisant librarie front-end | Rendu natif | Très performant, comparable aux natives | Applications nécessitant de hautes performances | Modeste |
| React Native avec Expo | Framework pour applications mobiles en React | Rendu natif | Très performant, comparable aux natives | Applications complexes avec intégration de composants natifs | Très large et active |

Table 4.3 - Comparaison des frameworks pour le développement d'applications mobile multiplateformes