---
source_file: rapport_mindlet.pdf
page_number: 32
total_pages: 32
total_images: 0
---

# 4.3.2 Comparaison des frameworks back-end 

| Framework | Performance | Évolutivité | Communauté | Facilité d'utilisation |
| :--: | :--: | :--: | :--: | :--: |
| NestJS | Bonne, support natif pour les microservices et WebSockets. | Modulaire, idéal pour les projets complexes. | Large et en croissance. | Documentation exhaustive, approche structurée. |
| Express.js | Correcte, adapté pour des applications légères. | Limité sans architecture supplémentaire. | Très grande, riche en extensions. | Simple à prendre en main, flexible mais peu structuré. |
| Fastify | Excellente, très rapide grâce à son modèle asynchrone. | Adapté pour des API performantes. | Moins grande que celle d'Express. | Facile à utiliser, mais nécessite plus de configuration que NestJS. |
| Django | Bonne pour des applications classiques. | Limité pour des architectures modernes modulaires. | Grande, bien établie. | Facile à utiliser, fonctionnalités out-of-the-box. |
| Flask | Correcte, orienté pour des microservices légers. | Faible sans structure complémentaire. | Moyenne mais active. | Flexible mais nécessite beaucoup de configurations. |
| FastAPI | Très bonne, support natif pour l'asynchrone. | Adapté pour des API performantes et scalables. | Moyenne, en croissance. | Facile avec des fonctionnalités modernes. |
| Hono | Excellente, rapide et légère grâce au routeur RegExpRouter. | Très flexible, support multiruntime. | Moyenne mais en croissance rapide. | APIs propres, support TypeScript de premier ordre, DX agréable. |

Table 4.6 - Comparaison des frameworks back-end

### 4.3.3 Conclusion :

Après une analyse approfondie des différentes options, nous avons retenu deux outils pour le développement back-end : Hono avec Bun ainsi que FastAPI. Ce choix reflète notre volonté de nous aventurer dans les solutions de nouvelle génération tout en capitalisant sur la simplicité et la performance.