---
source_file: rapport_mindlet.pdf
page_number: 12
total_pages: 32
total_images: 0
---

# Chapitre 3 

## Besoins fonctionnels

### 3.1 Fonctionnalités essentielles

### 3.1.1 Création assistée par IA

Les utilisateurs peuvent facilement créer des collections de cartes d'apprentissage (flashcards) en soumettant une simple requête, telle que : «Liste des capitales d'Europe». L'intelligence artificielle de Mindlet génère instantanément une série de cartes de révision pertinentes et adaptées au sujet demandé, offrant ainsi un gain de temps considérable tout en éliminant la nécessité de rechercher les informations manuellement.

### 3.1.2 Méthodes d'apprentissage diversifiées

- Flashcards : Les cartes permettent un apprentissage basé sur la répétition espacée, une méthode prouvée pour améliorer la mémorisation à long terme. Chaque carte présente une question d'un côté et une réponse de l'autre, incitant l'utilisateur à se tester régulièrement.
- Quiz : Les utilisateurs peuvent concevoir des quiz pour tester leurs connaissances sur un sujet donné. Ces quiz peuvent inclure des questions à choix multiples, des réponses ouvertes, ou des exercices de correspondance. Cela permet une auto-évaluation en temps réel pour mesurer la maîtrise des connaissances.
- Match (Jeu de correspondance) : Cette fonctionnalité ludique permet aux utilisateurs d'associer des notions à leurs définitions. C'est un moyen efficace pour renforcer la compréhension et la mémoire par l'interaction.


### 3.1.3 Apprentissage collaboratif

- Collections collaboratives : Les collections de cartes peuvent être créées de manière collaborative. Par exemple, un étudiant peut créer une collection basée sur ses cours, puis permettre à ses amis ou collègues de la compléter ou de la modifier. Les utilisateurs peuvent scanner des extraits de leurs livres ou cours pour enrichir le contenu, et d'autres peuvent contribuer avec des corrections ou ajouts via l'IA, rendant l'apprentissage plus dynamique.