---
source_file: rapport_mindlet.pdf
page_number: 20
total_pages: 32
total_images: 1
images:
- id: img-0.jpeg
  filename: page20_img1.jpg
  image_type: schema
  title: Schéma de la base de données
  description: Schéma de la base de données pour une application de messagerie et
    de gestion de collections.
  detailed_description: Ce schéma de base de données montre les différentes tables
    et leurs relations pour une application de messagerie et de gestion de collections.
    Les tables incluent DirectChat, DirectChatMessage, GroupChat, GroupChatMember,
    Message, Notification, User, Card, Collection, CollectionCollaborator, CollectionInvitation,
    CardProgression, GameSession, GameMode, GameModeSetting, UserLike, UserFeature,
    et Feature. Chaque table est détaillée avec ses champs respectifs et leurs types
    de données.
---

![[schema] - Schéma de la base de données](images/page20_img1.jpg)

Figure 3.3 - Modèle conceptuel de données