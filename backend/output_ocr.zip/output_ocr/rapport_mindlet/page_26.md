---
source_file: rapport_mindlet.pdf
page_number: 26
total_pages: 32
total_images: 0
---

# 4.1.2 Comparaison des frameworks front-end 

| Framework | Astro | Next.js | SvelteKit | SolidStart | Qwik <br> City | Angular |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Rendu | SSR, SSG, <br> ISR | SSR, SSG, <br> ISR, CSR | SSR, SSG, CSR | SSR, SSG, CSR | SSR, SSG, CSR | SSR, CSR |
| Modularité | Islands Architecture | Composants <br> React | Composants <br> Svelte | Composants <br> Solid | Composants Qwik | Composants <br> Angular |
| Approche front-end | Découplage du rendu statique et dynamique pour optimiser le chargement | Rendu côté serveur par défaut, hybride possible | Hydratation progressive, focus sur la performance | Hydratation finegrained, optimal pour la réactivité | Chargement progressif avec des "islands" | Fullframework, MVC |
| Gestion du contenu | Idéal pour sites à base de contenu avec composants interactifs | Adapté pour sites web, blogs, et applications complexes | Idéal pour les sites avec des interactions fluides | Idéal pour appli- cations hautement interactives | Parfait pour sites interactifs et applications ultraperformantes | Fort pour les appli-cations complexes et les grandes entreprises |
| Optimisation du rendu | Ultraoptimisé, chargement conditionnel des composants | Bon, avec des optimisations telles que le static optimization | Excellente, grâce à la compilation Svelte | Très performant, grâce au re-rendu efficace | Optimisé pour le rendu progressif et l'hydratation minimaliste | Performant mais avec une courbe d'apprentissage plus raide |
| Langage et syntaxe | Astro, <br> HTML, <br> JSX, TSX <br> MD et <br> MDX | JSX et <br> TSX | JSX, TSX <br> Svelte syntax | JSX et <br> TSX | JSX et <br> TSX | TypeScript <br> Angular <br> syntax |

Table 4.2 - Comparaison des frameworks front-end