---
source_file: rapport_mindlet.pdf
page_number: 25
total_pages: 32
total_images: 0
---

# Conclusion 

Nous avons choisi d'utiliser une combinaison de Solid.js et React pour tirer parti des forces de chacune de ces librairies.

Solid.js sera utilisé pour les parties critiques de l'application où la performance est primordiale, comme la gestion des états dans les sections liées au gameplay. Grâce à sa réactivité fine-grain et à l'absence de Virtual DOM, Solid.js offre des mises à jour rapides et directes du DOM, garantissant des performances exceptionnelles dans les scénarios exigeants.

En parallèle, nous intégrerons React pour tirer profit de son vaste écosystème, de sa communauté active et de sa bibliothèque de composants éprouvés. Cet écosystème riche nous permettra d'accélérer le développement des parties moins critiques en termes de performance, tout en bénéficiant de ressources abondantes et de solutions prêtes à l'emploi.

Ces deux librairies coexisteront harmonieusement grâce à l'utilisation d'Astro, un framework que nous détaillerons dans la section suivante. Astro permet de combiner différentes technologies front-end dans un même projet, assurant une intégration fluide entre Solid.js et React. Cette approche hybride maximise la performance tout en tirant parti de la richesse de l'écosystème React, répondant ainsi parfaitement aux besoins variés de notre application.

- Performance : Solid.js offre des performances optimales grâce à sa compilation en JavaScript natif, particulièrement dans les scénarios nécessitant une gestion réactive et rapide des états.
- Écosystème et communauté : React bénéficie d'un écosystème riche, d'une vaste communauté active, et d'une large bibliothèque de composants.
- Interopérabilité : L'utilisation d'Astro permet à Solid.js et React de coexister harmonieusement dans le même projet.