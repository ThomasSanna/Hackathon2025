---
source_file: rapport_mindlet.pdf
page_number: 24
total_pages: 32
total_images: 0
---

# 4.1.1 Comparaison des librairies front-end 

| Librairie | Rendu | Performance | Communauté | Mode d'écriture |
| :--: | :--: | :--: | :--: | :--: |
| React | Calculs de diff entre le Virtual DOM et le DOM réel pour appliquer les changements efficacement. | Performant, moins optimal pour des applications complexes sans bonnes pratiques. | Grande communauté, vaste quantité de ressources et de bibliothèques. | Utilise JSX avec des hooks pour une programmation fonctionnelle. |
| Vue.js | Utilise un Virtual DOM simplifiée et une réactivité finegrain. | Très performant, mise à jour efficace grâce à la réactivité fine-grain. | Communauté importante | Structure en composants basés sur des fichiers .vue divisés en sections template, script, et style. |
| Svelte | Pas de Virtual DOM. Compilateur transformant le code en JavaScript. | Performances exceptionnelles grâce à l'absence de virtualisation. | Communauté en forte croissance, bien que plus petite que celles de React et Vue. | Code écrit de manière déclarative, similaire à Vue, mais sans phase de virtualisation. |
| Solid.js | Utilise une réactivité fine-grain (effecteurs réactifs) sans Virtual DOM. | Très rapide, rivalise avec Svelte. | Communauté plus petite, mais active et enthousiaste | Composants fonctionnels avec hooks, approche réactive fine-grain. |
| Qwik | Utilise un système de rendu "resumable" pour une hydratation optimisée sans Virtual DOM. | Ultra-rapide au rendu initial, charge dynamique du JavaScript, optimisé. | Relativement nouveau mais en croissance. Miško Hevery, le créateur d'Angular. | Syntaxe basée sur des composants avec une logique de "rendering on demand". |

Table 4.1 - Comparaison des librairies front-end