---
source_file: rapport_mindlet.pdf
page_number: 27
total_pages: 32
total_images: 0
---

# Conclusion 

Nous avons choisi Astro pour sa flexibilité unique dans le choix des librairies de composants réactifs, permettant un contrôle précis sur leur chargement et leur interaction. Cette approche optimise le rendu et la gestion des interactions de notre application.

Astro se distingue par sa rapidité, supprimant le JavaScript par défaut pour un chargement ultra-rapide et une expérience fluide, même sur des connexions limitées. Son modèle sans Virtual DOM et l'utilisation d'un CDN garantissent un déploiement réactif et des performances maximales. De plus, dans les composants Astro, on bénéficie de la performance du JavaScript vanilla tout en ayant la possibilité d'utiliser des composants réactifs, ce qui est unique à ce méta-framework.

Pour répondre à des besoins de réactivité et de performance, notamment pour les jeux, le chat et les fils d'actualité en temps réel, Astro utilise l'Island Architecture pour charger uniquement les composants interactifs, améliorant ainsi la vitesse de rendu. Il permet de combiner des technologies comme React, Vue ou Solid, offrant le meilleur compromis entre performance et maintenabilité.

Astro offre un contrôle total sur le préchargement et le rendu conditionnel des ressources, minimisant les temps de chargement et la consommation de bande passante grâce à des optimisations automatiques telles que la division du code et le chargement différé.

En résumé, Astro est une solution performante et flexible qui maximise les performances et garantit une expérience utilisateur de qualité, que ce soit pour des interactions en temps réel ou du contenu statique optimisé.

### 4.2 Mobile et desktop

Pour développer notre application mobile et desktop, il est possible de choisir entre deux grandes options : utiliser des technologies natives pour chaque plateforme (Swift ou Objective-C pour iOS, Kotlin pour Android, C\# pour Windows) ou opter pour une approche multiplateforme. Nous avons décidé de ne pas choisir la première option, car elle nécessiterait de gérer des bases de code distinctes pour chaque plateforme, ce qui est complexe et n'est pas adapté à notre niveau de connaissance dans ces technologies.

Ainsi, nous avons choisi d'utiliser l'écosystème JavaScript, qui nous permet de partager les composants entre le web, le mobile et le desktop. Cela nous simplifie la gestion des codes et nous garantit une meilleure cohérence entre les différentes versions de notre application.

### 4.2.1 Options disponibles dans l'écosystème JavaScript

Mobile