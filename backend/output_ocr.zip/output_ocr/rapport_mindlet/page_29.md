---
source_file: rapport_mindlet.pdf
page_number: 29
total_pages: 32
total_images: 0
---

# Desktop 

| Nom | Description | Rendu | Performance | Utilisation | Communauté |
| :-- | :-- | :-- | :-- | :-- | :-- |
| Electron | Framework pour <br> applications <br> desktop multi- <br> plateformes avec <br> technologies web | Chromium <br> et Node.js | Consommation <br> mémoire élevée | Applications <br> complexes <br> (Slack, VS- <br> Code) | Très vaste et <br> bien soutenue |
| NW.js <br> (node- <br> webkit) | Framework simi- <br> laire à Electron, <br> avec traitement <br> Node.js intégré | Chromium <br> et Node.js | Comparable à <br> Electron | Applications de <br> bureau simples <br> à modérées | Significative |
| Proton <br> Native | Framework pour <br> applications na- <br> tives avec React | Composants <br> natifs | Haute, plus ef- <br> ficace que Web- <br> View | Applications <br> nécessitant une <br> interface fluide | Faible, en crois- <br> sance |
| Tauri | Framework pour <br> applications <br> desktop légères <br> et sécurisées | Moteur <br> web léger <br> + bindings <br> Rust | Très perfor- <br> mant et léger | Applications en <br> tout genre avec <br> un haut niveau <br> de sécurité | Moyenne, en ex- <br> pansion |

Table 4.4 - Comparaison des frameworks pour le développement d'applications desktop

### 4.2.2 Conclusion

Pour choisir nos technologies pour le développement mobile et desktop, nous avons adopté une approche similaire à celle utilisée pour le choix de notre technologie front-end web : donner la priorité aux performances. À l'instar de frameworks comme Astro et Solid, qui optimisent les performances grâce à une architecture native et légère, nous avons opté pour React Native pour le développement mobile. Cette librairie se distingue par son rendu natif, permettant de produire des applications performantes tout en exploitant une base de code JavaScript. De plus, React Native bénéficie de la communauté la plus vaste et la mieux soutenue parmi les solutions mobiles, ce qui facilite la résolution de problèmes et l'accès à des ressources.

En ce qui concerne le développement desktop, les options pour utiliser des composants à partir de JavaScript sont malheureusement plus limitées. Bien que Proton Native propose une alternative intéressante pour le rendu natif, sa communauté est très restreinte, et la documentation est insuffisante, voire inexistante pour certains cas d'utilisation. Electron, souvent adopté par de grandes entreprises, constitue un choix populaire, mais il repose sur Chromium, ce qui peut entraîner une application lourde et gourmande en ressources.