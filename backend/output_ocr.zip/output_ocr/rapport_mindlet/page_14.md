---
source_file: rapport_mindlet.pdf
page_number: 14
total_pages: 32
total_images: 0
---

etc.). Cela permet d'adapter le contenu aux préférences d'apprentissage de chaque utilisateur (visuel, auditif, kinesthésique).

- Apprentissage adaptatif : L'application ajuste la fréquence et la difficulté des révisions en fonction des performances passées de l'utilisateur, permettant un apprentissage plus efficace. Par exemple, l'IA peut décider de montrer certaines cartes plus fréquemment si elles sont mal maîtrisées, ou de ralentir la révision de certaines cartes si l'utilisateur les connaît bien. Ce système de révision adaptative maximise l'efficacité de l'apprentissage.


# 3.1.7 Accessibilité et multi-plateformes 

- Disponibilité multiplateforme : Mindlet est conçu pour être accessible sur plusieurs plateformes : iOS, Android, Windows, macOS, Linux, et via un navigateur web. Les utilisateurs peuvent commencer leur révision sur leur smartphone, continuer sur leur tablette ou leur ordinateur de bureau, ce qui leur offre une flexibilité totale. Le système de synchronisation en temps réel permet de reprendre l'apprentissage où que l'on soit, à tout moment.
- Accessibilité pour tous : L'application propose des fonctionnalités d'accessibilité pour les personnes ayant des besoins particuliers, comme des options de lecture audio pour les cartes, des contrastes de couleurs ajustables et une interface simple et intuitive pour les utilisateurs moins familiers avec les technologies.


### 3.2 Cas d'utilisations

Le schéma ?? présente l'ensemble des actions possibles pour un utilisateur au sein de l'application. Il est détaillé et organisé par catégories spécifiques. Par exemple, un utilisateur peut créer une collection et y ajouter des cartes (flashcards). Une fois sa collection complétée, il peut lancer une partie de jeu, telle que des flashcards, des quiz ou des jeux de correspondance.