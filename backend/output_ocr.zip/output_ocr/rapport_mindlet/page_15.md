---
source_file: rapport_mindlet.pdf
page_number: 15
total_pages: 32
total_images: 1
images:
- id: img-0.jpeg
  filename: page15_img1.jpg
  image_type: diagram
  title: Diagramme de cas d'utilisation
  description: Un diagramme de cas d'utilisation pour une application
  detailed_description: Ce diagramme de cas d'utilisation illustre les différentes
    fonctionnalités et interactions pour un utilisateur d'une application. Il inclut
    des cas d'utilisation tels que l'authentification, la gestion des decks, des cartes,
    des parties de jeu, de la messagerie, des recommandations, des paramètres, des
    profils utilisateurs, et des fonctionnalités de l'application. Chaque cas d'utilisation
    est détaillé avec des actions spécifiques que l'utilisateur peut effectuer.
---

![[diagram] - Diagramme de cas d'utilisation](images/page15_img1.jpg)

Figure 3.1 - Schéma représentant les cas d'utilisations de l'application