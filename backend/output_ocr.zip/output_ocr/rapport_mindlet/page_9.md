---
source_file: rapport_mindlet.pdf
page_number: 9
total_pages: 32
total_images: 0
---

# Menaces 

- Concurrence élevée : Des applications établies comme Anki, Quizlet ou Duolingo dominent déjà le marché. Mindlet devra se différencier par des fonctionnalités uniques pour capter l'attention des utilisateurs.
- Évolution rapide des technologies et des attentes : Le marché des technologies éducatives évolue rapidement, ce qui signifie que Mindlet devra constamment innover pour répondre aux attentes des utilisateurs.
- Régulations sur les données personnelles : La gestion des données personnelles et la conformité au RGPD pourraient devenir un point de friction, en particulier dans le cadre de l'utilisation de l'IA.


### 2.6 Cibles principales

## - Étudiants :

- Besoins : Apprendre de manière plus efficace, avec des outils qui augmentent leur rétention d'information (répétition espacée, flashcards, quizz, défis).
- Comportements : Souvent à la recherche de moyens plus interactifs et motivants pour étudier, ils aiment partager des ressources avec leurs amis et participer à des jeux ou concours.
- Professionnels et adultes en formation continue :
- Besoins : Flexibilité, apprentissage personnalisé, ressources adaptées à des créneaux horaires réduits.
- Comportements : Préférence pour des outils efficaces qui maximisent leur temps, permettant de réviser de manière autonome et structurée.
- Enseignants et formateurs :
- Besoins : Créer et partager des ressources, faciliter l'apprentissage collaboratif, suivre les progrès des étudiants.
- Comportements : Cherchent des outils simples à utiliser pour leurs élèves, avec des fonctionnalités collaboratives et de suivi des performances.
- Passionnés d'apprentissage continu :
- Besoins : Outils diversifiés pour un apprentissage flexible et ludique, ainsi qu'une communauté pour échanger des connaissances.
- Comportements : Recherche d'applications qui offrent une expérience personnalisée, gamifiée, et qui offrent un contenu infini à explorer.
Valeurs de Mindlet :
- Innovation et personnalisation : L'utilisation de l'IA pour proposer des cartes d'apprentissage personnalisées et optimiser la méthode de révision de chaque utilisateur est au cœur de Mindlet.
- Communauté et partage : Mindlet met un point d'honneur à favoriser l'entraide, la collaboration et le partage entre utilisateurs.
- Accessibilité : L'application est disponible sur plusieurs plateformes, ce qui permet à chacun d'apprendre où et quand il le souhaite, avec un design simple et intuitif.