---
source_file: rapport_mindlet.pdf
page_number: 16
total_pages: 32
total_images: 1
images:
- id: img-1.jpeg
  filename: page16_img1.jpg
  image_type: diagram
  title: Flux utilisateur pour la création et la gestion de decks
  description: Diagramme de flux utilisateur pour la création et la gestion de decks
    dans une application.
  detailed_description: Ce diagramme de flux utilisateur illustre les différentes
    étapes et interactions pour créer et gérer des decks dans une application. Il
    commence par l'écran de connexion ou de création de compte, puis guide l'utilisateur
    à travers les processus de création de decks, d'ajout de cartes, et de modification
    des decks. Les différentes étapes sont connectées par des flèches indiquant le
    flux de navigation entre les écrans.
---

# 3.3 Maquettes fonctionnelles et arborescence 

Le schéma ?? illustre l'architecture de l'expérience utilisateur (UX) globale de l'application, de la connexion initiale à la création de la collection, l'ajout de cartes, jusqu'à l'entraînement. L'objectif de ce diagramme est de guider la conception de la maquette fonctionnelle, en définissant les principes fondamentaux de l'architecture de l'information, l'arborescence de l'application, tout en offrant une vision claire et fluide de l'ergonomie cognitive et interactionnelle.
![[diagram] - Flux utilisateur pour la création et la gestion de decks](images/page16_img1.jpg)

Figure 3.2 - UX de l'application
Le parcours utilisateur (UX) a été pensé selon les principes de l'efficacité cognitive, de la minimisation des frictions et du design centré sur l'utilisateur (UCD). Il a été structuré pour que l'utilisateur atteigne ses objectifs (récompenses) en un maximum de trois clics, en s'appuyant sur des concepts de «low cognitive load» et «progressive disclosure». Cette approche réduit le besoin d'effort mental, en favorisant l'accès immédiat aux informations pertinentes et en éliminant les distractions inutiles, ce qui améliore la performance de la navigation et la satisfaction de l'utilisateur.

## Exemples :

- Lors de la première interaction avec l'application, du processus de création du compte au lancement de l'entraînement (récompense), l'utilisateur traverse uniquement trois pages, ce qui