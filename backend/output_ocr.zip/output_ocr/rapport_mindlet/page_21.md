---
source_file: rapport_mindlet.pdf
page_number: 21
total_pages: 32
total_images: 0
---

# 3.4.1 Gestion des utilisateurs 

L'entité principale de cette partie est User, qui représente chaque utilisateur de l'application.

- Champs importants :
- userId : identifiant unique.
- email et username : informations pour identifier chaque utilisateur.
- roles : rôle de l'utilisateur (USER, STAFF, OWNER).
- Relations principales :
- Un utilisateur peut avoir plusieurs collections, cartes, notifications ou messages.
- UserLike : suit les 'likes' entre utilisateurs.
- Notifications : gère les alertes ou mises à jour envoyées aux utilisateurs.


### 3.4.2 Gestion des collections

Les collections regroupent des cartes et permettent la collaboration entre utilisateurs.

- Champs importants :
- collectionId : identifiant unique.
- ownerId : utilisateur propriétaire de la collection.
- visibility : définit si une collection est publique ou privée.
- Relations principales :
- Une collection contient plusieurs cartes.
- Elle peut être partagée avec des collaborateurs grâce aux entités :
- CollectionInvitation : pour inviter des utilisateurs.
- CollectionCollaborator : pour définir leurs droits (lecture/écriture).


### 3.4.3 Gestion des cartes

Les cartes appartiennent aux collections et suivent l'apprentissage des utilisateurs.

- Champs importants :
- front et back : contenu de la carte (recto/verso).
- isActive : indique si la carte est active.
- Relations principales :
- CardProgression : suit l'état d'apprentissage de chaque carte (non vue, en apprentissage, apprise).


### 3.4.4 Gestion des jeux

Les sessions de jeu utilisent des modes prédéfinis pour rendre l'apprentissage interactif.

- Champs importants :
- title : nom du mode de jeu.
- isActive : indique si le mode est disponible.
- Relations principales :
- GameModeSetting : définit les paramètres des modes de jeu.
- GameSession : relie un utilisateur, une collection et un mode de jeu à une session.