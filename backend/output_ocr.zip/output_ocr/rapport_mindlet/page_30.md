---
source_file: rapport_mindlet.pdf
page_number: 30
total_pages: 32
total_images: 0
---

C'est pourquoi nous avons choisi Tauri pour nos applications desktop. Ce framework, qui utilise Rust pour la partie backend (gestion des appels de fonctions natives), combine légèreté et hautes performances. Rust, que nous aspirons également à apprendre, offre des garanties de sécurité mémoire et d'efficacité, faisant de Tauri une solution idéale pour des applications performantes et modernes. De plus, Tauri est en pleine expansion, avec une documentation complète et une communauté grandissante. Cette combinaison répond parfaitement à nos besoins en matière de performances et de maintenabilité.

# 4.3 Technologies back-end 

Pour le développement back-end, nous avons choisi d'utiliser TypeScript, le même langage que pour le front-end. Ce choix permet une homogénéité dans notre codebase, facilitant le partage de types et de fonctions entre les deux parties.

Cependant, nous sommes conscients que TypeScript, bien que performant pour un langage interprété, n'offre pas les performances d'un langage compilé comme Go ou Rust. Pour l'instant, notre priorité est la rapidité de développement et l'adoption d'une technologie que nous maîtrisons déjà, tout en restant ouverts à une évolution future vers des solutions plus performantes.