---
source_file: compte-rendu-50-2003.pdf
page_number: 2
total_pages: 8
total_images: 1
document_title: Compte rendu 50
language: fr
document_type: procès-verbal
images:
- id: img-0.jpeg
  filename: page2_img1.jpg
  image_type: logo
  title: Logo du National Geographic
  description: Logo du National Geographic avec une représentation stylisée de la
    Terre.
  detailed_description: Le logo du National Geographic présente une grande lettre
    'N' stylisée en noir, avec une représentation de la Terre intégrée dans la lettre.
    La Terre est détaillée avec des lignes de longitude et de latitude, et les continents
    sont visibles. Le design est simple mais distinctif, reflétant le thème géographique
    de la marque.
---

![[logo] - Logo du National Geographic](images/page2_img1.jpg)

INTERNATIONAL
NUMISMATIC COMMISSION
INTERNATIONALE
DE NUMISMATIQUE