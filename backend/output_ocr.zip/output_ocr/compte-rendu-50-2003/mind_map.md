# Carte Mentale - Compte rendu de la Commission internationale de numismatique (CIN) - Année 2003

```mermaid
mindmap
  root((Commission internationale de numismatique (CIN) - Année 2003))
    Structure et gouvernance
      Composition du Bureau
        Membres du Bureau
        Fonctions et responsabilités
      Statuts et Constitution
        Contenu des statuts
        Modifications et mises à jour
        Conditions de dissolution
      Affiliation
        Comité international des sciences historiques
    Gestion administrative et financière
      Comptes de la Commission
        Bilan financier 2003
        Siège de la CIN
      Assemblée générale
        Comptes rendus des réunions
        Décisions et résolutions
      Liste des membres
        Membres institutionnels
        Membres individuels
    Histoire et contributions numismatiques
      Numismates notables
        Articles et hommages
        Nécrologie [ex: Laura Breglia]
      Histoire des collections numismatiques
        Collections majeures
        Préservation et conservation
      Organisations partenaires
        Musées et institutions [ex: Kunsthistorisches Museum, Harvard University]
    Activités et réunions
      Comptes rendus des réunions du Bureau
        Réunions ordinaires
        Réunions extraordinaires
      Événements et collaborations
        Projets internationaux
        Publications et rapports
```
