---
source_file: compte-rendu-50-2003.pdf
page_number: 1
total_pages: 8
total_images: 0
document_title: Compte rendu 50
language: fr
document_type: procès-verbal
summary: Le document est un compte rendu de la Commission internationale de numismatique
  (CIN) pour l'année 2003. Il inclut la composition du bureau, les statuts, la constitution,
  des articles sur des numismates notables, l'histoire des collections numismatiques,
  une nécrologie, des comptes rendus de réunions, et des informations sur les membres
  de la commission. Le document détaille également les fonctions et les responsabilités
  du bureau, les finances, le siège, les modifications des statuts, et les conditions
  de dissolution de la CIN.
key_points:
- Composition du Bureau de la CIN
- Statuts et Constitution de la CIN
- Articles sur des numismates notables
- Histoire des collections numismatiques
- Nécrologie de Laura Breglia
- Comptes rendus des réunions du Bureau
- Comptes de la Commission
- Assemblée générale
- Liste des membres de la Commission
- Fonctions et responsabilités du Bureau
- Finances et siège de la CIN
- Modifications des statuts et dissolution
authors: []
date: '2003'
organizations:
- Commission internationale de numismatique (CIN)
- Comité international des sciences historiques
- Museo Arqueológico Nacional
- Dipartimento di Scienze dell'Antichità
- Harvard University Art Museums
- National Museum of Finland
- Hunterian Museum
- Kunsthistorisches Museum
- State Puskhin Museum of Fine Arts
- Münzkabinett und Antikensammlung der Stadt Winterthur
---

COMISIÓN INTERNACIONAL DE NUMISMÁTICA INTERNATIONAL NUMISMATIC COMMISSION COMMISSION INTERNATIONALE DE NUMISMATIQUE INTERNATIONALE NUMISMATISCHE KOMMISSION COMMISSIONE INTERNAZIONALE DI NUMISMATICA

# AFFILIÉE AU COMITÉ INTERNATIONAL DES SCIENCES HISTORIQUES 

## Compte rendu 50

2003