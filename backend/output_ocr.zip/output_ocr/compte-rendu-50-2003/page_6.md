---
source_file: compte-rendu-50-2003.pdf
page_number: 6
total_pages: 8
total_images: 0
document_title: Compte rendu 50
language: fr
document_type: procès-verbal
---

Conseillers: Dr. Donal BATESON, Hunterian Museum, Glasgow University, Glasgow G12 8QQ, United Kingdom. Tel + 44141330 4289, fax +441413303617 . E-mail : d.bateson@museum.gla.ac.uk

Prof. Dr. Günther DEMBSKI, Kunsthistorisches Museum, Münzkabinett, Burgring 5, A - 1010 Vienna, Austria
Tel. +43152524380 , fax +43152524353 , mobile +43664 52673 82. E-mail : guenther.dembski@khm.at

Dr. Natasha SMIRNOVA, State Puskhin Museum of Fine Arts, Numismatic Department, Volkhonka str. 12, RU - 119019 Moscow, Russia. Tel. + 709520374 14, fax +70952034674
E-mail : smirnovanataliya@mail.ru
Mr. Benedikt ZÄCH, Münzkabinett und Antikensammlung der Stadt Winterthur, Villa Bühler, Lindstrasse 8, Postfach 2402, CH - 8401 Winterthur, Switzerland. Tel. +41522675 146, fax +41522676 681. E-mail : benedikt.zaech@win.ch

# CIN home page / page d'accueil de la CIN <br> http://www.amnumsoc.org