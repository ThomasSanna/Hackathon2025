---
source_file: compte-rendu-50-2003.pdf
page_number: 5
total_pages: 8
total_images: 0
document_title: Compte rendu 50
language: fr
document_type: procès-verbal
---

# COMISIÓN INTERNACIONAL DE NUMISMÁTICA INTERNATIONAL NUMISMATIC COMMISSION COMMISSION INTERNATIONALE DE NUMISMATIQUE INTERNATIONALE NUMISMATISCHE KOMMISSION COMMISSIONE INTERNAZIONALE DI NUMISMATICA 

## BUREAU

elected on September 14th, 2003 in Madrid/élu le 14 septembre 2003 à Madrid
Président: M. Michel AMANDRY, Cabinet des Médailles de la Bibliothèque nationale de France, 58 rue de Richelieu, F - 75084 Paris cedex 02, France. Tel. +33153798363 , fax +33153798947
E-mail: michel.amandry@bnf.fr
Vice-présidents: Dr. Carmen ALFARO, Departamento de Numismática y Medallistica, Museo Arqueológico Nacional, c/Serrano 13, E - 28001 Madrid, Spain. Tel. +3415777912 , fax +3414316840 E-mail : caa@man.es

Prof. Giovanni GORINI, Dipartimento di Scienze dell'Antichità, Piazza Capitaniato 7, I - 35134 Padova, Italy.
Tel. +3904982745 98, fax +390498274613
E-mail : giovanni.gorini@unipd.it
Secrétaire: Mme Carmen ARNOLD-BIUCCHI, Harvard University Art Museums, Arthur M. Sackler Museum, Dept. of Ancient and Byzantine Art and Numismatics, 485 Broadway, Cambridge, MA 02138, USA. Tel + 1617496 9274, fax +16174955506
E-mail : biucchi@fas.harvard.edu
Trésorier: M. Tuukka TALVIO, Coin Cabinet, National Museum of Finland, P.O. Box 913, FL - 00101 Helsinki, Finland. Tel +35894050 435, fax +35894050 437. E-mail : tuukka.talvio@nba.fi