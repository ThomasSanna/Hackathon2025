---
source_file: compte-rendu-50-2003.pdf
page_number: 8
total_pages: 8
total_images: 0
document_title: Compte rendu 50
language: fr
document_type: procès-verbal
---

Art. 6. Charges. Les charges du Bureau sont la présidence, les deux vice-présidences, le secrétariat, la trésorerie. Les titulaires de ces charges sont élus immédiatement après l'élection du Bureau et exercent leur charge selon les vœux du Bureau. Lors du changement de Bureau, le trésorier reste en charge jusqu'à la fin de l'année civile.

Art. 7. Fonctions du Bureau. Les fonctions du Bureau comprennent l'admission de nouveaux membres, la préparation et la publication du budget et des comptes, la fixation du montant de la cotisation, la diffusion de l'information aux membres (notamment par le Compte rendu annuel et les Newsletters), le patronage de travaux individuels, de publications et de conférences de numismatique, l'organisation du Congrès international et toute autre activité relative, selon lui, aux objectifs de la CIN.

Art. 8. Finances. Les dépenses d'administration et de publication sont couvertes par les cotisations annuelles, les dons, les legs, et d'éventuelles subventions.

Art. 9. Siège. Le siège de la CIN se trouve au bureau du président.
Art. 10. Modifications des statuts. Toute modification des statuts doit être approuvée à la majorité des deux tiers des votes exprimés à l'assemblée générale. Toute proposition de modification doit être signifiée aux membres, par écrit, au moins trois mois avant l'assemblée.

Art. 11. Dissolution. La CIN peut être dissoute par la majorité des votes exprimés à l'assemblée générale. En cas de disssolution, les actifs de la CIN seront transférés au Comité international des sciences historiques.