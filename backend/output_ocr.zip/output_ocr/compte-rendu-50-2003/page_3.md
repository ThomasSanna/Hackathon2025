---
source_file: compte-rendu-50-2003.pdf
page_number: 3
total_pages: 8
total_images: 0
document_title: Compte rendu 50
language: fr
document_type: procès-verbal
---

# TABLE OF CONTENTS/SOMMAIRE 

Composition du Bureau ..... 7
Statuts ..... 9
Constitution ..... 11
Les grands numismates
Karl Pink (1884-1965) (Günther Dembski) ..... 13
Ivan G. Spassky (1904-1990) (Vitalii Kalinin) ..... 15
Histoire des collections numismatiques et des institutions vouées à la numismatique
The Alpha Bank Numismatic Collection in Athens (Dimitra Tsagari) ..... 17
Nécrologie
Laura Breglia (5 February 1912 - 2 June 2003) (Attilio Stazio) ..... 22
Réunion du Bureau (Madrid, 7-8 mars 2003) ..... 26
Comptes de la Commission ..... 27
Réunion du Bureau (Madrid, 14 septembre 2003) ..... 45
Assemblée générale / General Meeting (Madrid, 14 septembre 2003) ..... 46
Membres de la Commission
Institutions ..... 97
Membres honoraires ..... 115
Annual Scholarship of the INC ..... 127