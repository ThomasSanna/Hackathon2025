---
source_file: pv_1995-09-29.pdf
page_number: 8
total_pages: 8
total_images: 0
document_title: SEANCE DU 29 SEPTEMBRE 1995
language: fr
document_type: procès-verbal
---

- le compte BNP ouvert au nom de Madame Eugénie Ruth BIERRE a notamment été approvisionné par :
. le versement d'un chèque de 5000 US $\$$ provenant de la Whithney National Bank à la Nouvelle-Orléans -le 4 septembre 1991-semble-t-il ;
. le versement d'un chèque de 15400 US $\$$ tiré le 11 janvier 1995 sur un compte conjoint de Monsieur et Madame IMBERTON (respectivement mère et frère de Madame BIERRE) ;
. un virement de 60000 US $\$ 1$ e 7 juin 1995 provenant de Monsieur Carlos IMBERTON, frère de Madame BIERRE.

La contre-valeur en francs de ces paiements est d'environ 425000 F, montant qui serait à 50000 F près en rapport avec les versements consentis par Madame BIERRE à Monsieur CHEMINADE à partir de ce compte à la BNP.

Madame Eugénie Ruth BIERRE explique que les mouvements sur son compte à la BNP sont la "matérialisation" d'un emprunt auprès de son frère Carlos IMBERTON, citoyen de la république du Salvador.

- Le compte C4.929.610 GM ouvert dans le livre de la société des banques suisses à Genève et à partir duquel a été virée au compte du mandataire financier de Monsieur Jacques CHEMINADE, la somme de 975000 F, a pour titulaire Monsieur François BIERRE ; Madame Ruth BIERRE détient procuration sur ledit compte.

C'est Monsieur François BIERRE qui a donné l'ordre à la société des banques suisses d'établir le 2 juin 1995 un chèque anonyme au profit de Monsieur Pierre BONNEFOY, honorant ainsi l'engagement de prêt théoriquement souscrit par sa femme le même jour à Paris.

Selon les explications données par Madame BIERRE, le compte C4.929.610 GM aurait été alimenté par le produit d'une donation effectuée par sa mère à son bénéfice.

Cette donation a été enregistrée devant notaire à San Salvador postérieurement à sa réalisation. Un acte notarié dressé à San Salvador et daté du 25 mai 1995 a en effet été communiqué par Madame BIERRE au Conseil constitutionnel. Le montant de la donation tel qu'il apparaît dans ce document est de 150000 US \$. Selon les assertions de Madame BIERRE la matérialisation de la donation serait constituée par divers versements effectués entre 1991 et 1994 sur le compte de son mari à la société des banques suisses à Genève.

Pour preuves, l'intéressée a fourni copie de divers avis de crédit émanant de la Whitney National Bank à la Nouvelle-Orléans, du crédit suisse à Genève et de la Swiss Banking Corporation à New-York.