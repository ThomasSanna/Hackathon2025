---
source_file: pv_1995-09-29.pdf
page_number: 3
total_pages: 8
total_images: 0
document_title: SEANCE DU 29 SEPTEMBRE 1995
language: fr
document_type: procès-verbal
---

1'encaissement le 7 juillet 1995 en contradiction avec les dispositions du code électoral qui prévoient que le candidat ne peut avoir recueilli de fonds en vue du financement de sa campagne qu'avant la date où l'élection a été acquise soit le 7 mai 1995.

Cependant, au vu de la modicité de la somme en cause, il est proposé en opportunité d'écarter ce motif entraînant en droit le rejet du compte.

Dans son courrier du 25 septembre 1995, le candidat plaide en ce sens demandant à ne plus considérer "ce mouvement comme un don, mais comme une avance"(1). A preuve, l'attestation de Monsieur Christophe LAVERNHE, le donateur, datée du 20 septembre 1995, dans laquelle il soutient que cette somme de 50 F était bien une avance qui lui a été d'ailleurs remboursée depuis, alors même qu'il est pourtant destinataire d'un reçu-don à la date du 7 juillet 1995.
b) Apport du candidat au mandataire (poste 7030)

Sous cette rubrique est indiquée dans le compte une somme de 4 690490 F qui agrège :

- des prêts de personnes physiques au candidat pour 2980990 F , dont 2340990 F consentis à titre gratuit,
- le montant de deux emprunts bancaires pour 350000 F ,
- les avances du parti "fédération pour une nouvelle solidarité" pour 359500 F ,
- l'avance forfaitaire de l'Etat pour 1000000 de F.
(1) L'argument trahit en fait le caractère indéterminé et substituable des dons, avances et prêts dans le financement de la campagne de Monsieur Jacques CHEMINADE.